#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

int main(int argc, char *argv[])
{

    int pid, status;
    printf("The given program is going to be executed : %s\n", argv[1]);

    pid = fork();
    if (pid == 0)
    {
        execvp(argc[1], &argv[1]);
        printf("stderr, could not execute the given programe!");
    }
    else
    {
        pid = wait(&status);
    }
    return 0;
}