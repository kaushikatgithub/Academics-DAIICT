#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <math.h>

int main()
{
    int pid, status;
    int cid;
    
    pid = fork();
    if (pid == 0)
    {
        char *arg[] = {"202201472_Lab4_3_child", "c", "programe", NULL};
        execv("./202201472_Lab4_3_child", arg);
        cid = getpid();
    }
    else
    {
        pid = wait(&status);
        if (WIFEXITED(status))
        {
            int exit_status = WEXITSTATUS(status);
            printf("Child process with pid %d terminated, the exit code is : %d\n", cid, exit_status);
        }
    
        if (WIFSIGNALED(status))
        {
            psignal(WTERMSIG(status), "Exit Signal");
        }
        else
        {
            printf("Not signaled\n");
        }
    }
}
