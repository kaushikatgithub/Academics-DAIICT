#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <math.h>

int main()
{
    int n;
    int status;
    pid_t pid;
    printf("Enter number of cases : \n");
    scanf("%d", &n);

    pid_t pids[n];
    for (int i = 0; i < n; i++)
    {
        if ((pids[i] = fork()) < 0)
        {
            perror("fork");
            abort();
        }
        else if (pids[i] == 0)
        {
            char *arg[] = {"202201472_Lab4_4_expo_child", "c", "programe", NULL};
            execv("./202201472_Lab4_4_expo_child", arg);
            exit(0);
        }
    }

    while (n > 0)
    {
        pid = wait(&status);
        printf("Child with PID %d exited\n", pid);
        n--;
    }
}
