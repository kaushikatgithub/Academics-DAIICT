#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <math.h>
#include <stdlib.h>

int fact(int n)
{
    if (n == 0)
        return 1;
    else
        return fact(n - 1) * n;
}

int main()
{
    float x;
    int n;
    printf("Enter x and n : \n");
    scanf("%f %d", &x, &n);
    float result = 0;

    for (int i = 0; i < n; i++)
    {
        float p = pow(x, i);
        result += p / fact(i);
    }

    printf("The result of exp(x, n) is : %f\n", result);
    exit(result);
}
