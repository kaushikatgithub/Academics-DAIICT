#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

int main()
{
    int pid1, status1;
    pid1 = fork();
    
    if (pid1 == 0)
    {
        execl("/bin/ls", "/bin/ls", "-l", "-t", "-r", NULL);
        printf("\n");
    }
    else
    {
        int pid2, status2;
        pid2 = fork();
        
        if (pid2 == 0)
        {
            char *arg[] = {"/bin/ls", "-l", "-t", "-r", NULL};
            execv(arg[0], arg);
            printf("\n");
        }
        else
        {
            int pid3, status3;
            pid3 = fork();
            if (pid3 == 0)
            {
                execlp("ls", "ls", "-l", "-t", "-r", NULL);
                printf("\n");
            }
            else
            {
                int pid4, status4;
                pid4 = fork();
                if (pid4 == 0)
                {
                    char *arg[] = {"/bin/ls", "-l", "-t", "r", NULL};
                    execvp("ls", arg);
                }
                else
                {
                    pid4 = wait(&status4);
                }

                pid3 = wait(&status3);
            }

            pid2 = wait(&status2);
        }

        pid1 = wait(&status1);
    }
    return 0;
}
