#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>

#define F_3 (3 * 1024 * 1024) // 3 MB
#define B_10  10
#define B_1KB (1 * 1024)
#define B_3MB (3 * 1024 * 1024)

void read_UnBuf(int fd, int fileSize) {
    char buffer[B_10  ];
    int bytesRead;

    lseek(fd, 0, SEEK_SET);

    clock_t start = clock();

    while ((bytesRead = read(fd, buffer, B_10  )) > 0) {
        // read 
    }

    clock_t end = clock();
    double elapsed = ((double)(end - start)) / CLOCKS_PER_SEC;

    printf("Unbuffered Read (Buffer Size 10B): %lf seconds\n", elapsed);
}

void read_Buf(FILE *file) {
    char buffer[B_10  ];

    fseek(file, 0, SEEK_SET);

    clock_t start = clock();

    while (fread(buffer, 1, B_10  , file) > 0) {
        // read 
    }

    clock_t end = clock();
    double elapsed = ((double)(end - start)) / CLOCKS_PER_SEC;

    printf("Buffered Read (Buffer Size 10B): %lf seconds\n", elapsed);
}

void wr_un(int fd, int fileSize) {
    char buffer[B_10  ];
    memset(buffer, 'A', B_10  );

    lseek(fd, 0, SEEK_SET);

    clock_t start = clock();

    for (int i = 0; i < fileSize / B_10  ; i++) {
        write(fd, buffer, B_10  );
    }

    clock_t end = clock();
    double elapsed = ((double)(end - start)) / CLOCKS_PER_SEC;

    printf("Unbuffered Write (Buffer Size 10B): %lf seconds\n", elapsed);
}

void wr_buf(FILE *file, int fileSize) {
    char buffer[B_10  ];
    memset(buffer, 'A', B_10  );

    fseek(file, 0, SEEK_SET);

    clock_t start = clock();

    for (int i = 0; i < fileSize / B_10  ; i++) {
        fwrite(buffer, 1, B_10  , file);
    }

    fflush(file);

    clock_t end = clock();
    double elapsed = ((double)(end - start)) / CLOCKS_PER_SEC;

    printf("Buffered Write (Buffer Size 10B): %lf seconds\n", elapsed);
}

int main() {
  
    int fd_unbuf = open("sample.txt", O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
    FILE *file_buf = fopen("sample.txt", "w");


    if (fd_unbuf == -1 || file_buf == NULL) {
        perror("Error creating/opening files");
        return 1;
    }

    int fileSize = F_3;

    printf("File Size: %d bytes\n", fileSize);


    read_UnBuf(fd_unbuf, fileSize);
    wr_un(fd_unbuf, fileSize);


    read_Buf(file_buf);
    wr_buf(file_buf, fileSize);


    close(fd_unbuf);
    fclose(file_buf);

    return 0;
}
