#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void Replace(char *input, char *search, char *replace, int *occurrence, int* cnt, int* f) {
  int len = strlen(input);
  int slen = strlen(search);
  int rlen = strlen(replace);
  int flag = (*f == 0) ? 0 : 1;
  if(*cnt == *occurrence) flag = 1;
  while(*input){
    if(strncmp(input, search, slen) == 0){
      if(flag && *cnt >= *occurrence){
        printf("%s", replace);
        input += slen;
        flag = (*f == 0) ? 0 : 1;
      }else{
        printf("%c", *input++);
      }

      if((*f == 0) && ((*cnt) == ((*occurrence)-1))){
        flag = 1;
      }
      (*cnt)++;
    }else{
      printf("%c", *input++);
    }
  }
}

void findSearch(char* arg, char** search, char** replace, int* occurrence, int* flag){
  strtok(arg, "/");
  *search = strtok(NULL, "/");
  *replace = strtok(NULL, "/");
  char* temp = strtok(NULL, "/");
  if(temp == NULL){
    *flag = 0;
    *occurrence = 1;
    return;
  }
  if(*temp == 'g'){
    *flag = 1;
  }else{
    int len = strlen(temp);
    if(temp[len - 1] == 'g'){
      *flag = 1;
      len--;
    }else{
      *flag = 0;
    }
    for(int i = 0; i < len; i++){
      *occurrence = (*occurrence)*10 + (temp[i] - '0');
    }
  }

  if(*occurrence == 0) (*occurrence)++;
  
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        fprintf(stderr, "Usage: %s search replace [n] filename\n", argv[0]);
        return 1;
    }

    char *search;
    char *replace;
    int occurrence = 0, f = 1;
    findSearch(argv[1], &search, &replace, &occurrence, &f);

    FILE *file = fopen(argv[2], "r");
    if (file == NULL) {
        perror("Error opening file");
        return 1;
    }

    char line[1024];
    int cnt = 1;
    while (fgets(line, sizeof(line), file)) {
        Replace(line, search, replace, &occurrence, &cnt, &f);
    }

    fclose(file);

    return 0;
}


