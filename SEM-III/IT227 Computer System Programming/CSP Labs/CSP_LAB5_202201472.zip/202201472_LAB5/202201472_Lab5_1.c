#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>

void list_files_recursive(const char *path) {
    DIR *dir;
    struct dirent *entry;

    dir = opendir(path);
    if (dir == NULL) {
        perror("opendir");
        exit(EXIT_FAILURE);
    }

    while ((entry = readdir(dir))) {
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
            continue;
        }

        char fullpath[1024];  
        snprintf(fullpath, sizeof(fullpath), "%s/%s", path, entry->d_name);

        printf("%s\n", fullpath);

        if (entry->d_type == DT_DIR) {
            list_files_recursive(fullpath);
        }
    }

    closedir(dir);
}

int main(int argc, char *argv[]) {
    const char *directory = ".";

    if (argc > 1) {
        directory = argv[1];
    }

    list_files_recursive(directory);

    return 0;
}
