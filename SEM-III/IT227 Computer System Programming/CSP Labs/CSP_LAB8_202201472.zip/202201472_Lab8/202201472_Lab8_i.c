#include<stdio.h>
#include<sys/mman.h>
#include<stdlib.h>
#include<unistd.h>

struct FMB{
    size_t size;
    struct FMB *next;
};

char *vir_mem = NULL;
struct FMB *flist = NULL;

void allocate_malloc() {

    vir_mem = (char *)mmap(NULL, 16384, PROT_READ | PROT_WRITE, MAP_ANON | MAP_PRIVATE, -1, 0);

    if (vir_mem == MAP_FAILED) {

        printf("Failed to map!\n");
        exit(1);
    }
}

int main() {

    allocate_malloc();
    printf("Dynamically Memory Allocated using allocate_malloc() function.\n");
    
    return 0; 
}

