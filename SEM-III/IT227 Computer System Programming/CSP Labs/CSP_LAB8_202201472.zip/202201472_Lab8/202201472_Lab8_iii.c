#include<stdio.h>
#include<stdlib.h>
#include<sys/mman.h>

char *vir_mem = NULL;
struct FMB *fList = NULL;

struct FMB {
    size_t size;
    struct FMB *next;
};

void mymalloc(int n) {

    vir_mem = (char *)mmap(NULL, n * 1024, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

    if (vir_mem == MAP_FAILED) {

        perror("Failed to map!");
        exit(1);
    }

    fList = (struct FMB *)vir_mem;
    fList->size = n * 1024;
    fList->next = NULL;
}

void split(struct FMB *block, size_t size) {

    if (block->size > size + sizeof(struct FMB)) {

        struct FMB *newBlock = (struct FMB *)((char *)block + size + sizeof(struct FMB));
        newBlock->size = block->size - size - sizeof(struct FMB);
        newBlock->next = block->next;
        block->size = size;
        block->next = newBlock;
    }
}

void coalesce() {

    struct FMB *current = fList;
    struct FMB *prev = NULL;

    while (current && current->next) {

        if ((char *)current + current->size + sizeof(struct FMB) == (char *)current->next) {

            current->size += current->next->size + sizeof(struct FMB);
            current->next = current->next->next;
        }

        prev = current;
        current = current->next;
    }
}

void *myMallocV1(size_t size) {

    struct FMB *current = fList;
    struct FMB *prev = NULL;

    while (current) {
        
        if (current->size >= size) {

            if (current->size > size + sizeof(struct FMB)) {
                split(current, size);
            }

            if (prev) {
                prev->next = current->next;
            } else {
                fList = current->next;
            }

            return (char *)current + sizeof(struct FMB);
        }

        prev = current;
        current = current->next;
    }

    return NULL;
}

void myfree(void *ptr) {

    if (ptr) {
        struct FMB *block = (struct FMB *)((char *)ptr - sizeof(struct FMB));
        block->next = fList;
        fList = block;
    }
}

int main() {

    int n = 16; 
    mymalloc(n);

    char *m1 = (char *)myMallocV1(128);
    char *m2 = (char *)myMallocV1(256);

    if (m1 && m2) {   
    	printf("Executed the function myMalloc().\n");
        printf("Dynamically Memory Allocated using allocate_malloc() function.\n");
    } else {
        printf("Error in Dynamically Allocating Memory!\n");
    }

    myfree(m1);
    myfree(m2);

    return 0;
}

