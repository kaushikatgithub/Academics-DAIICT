#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>
#include<math.h>

#define POOL_SIZE 1024 
#define MIN_BLK_SIZE 16  


struct FMB {
    bool is_free;
    size_t size;
    struct FMB* next;
};


char memory_pool[POOL_SIZE];


void init_Allocator() {
    
    struct FMB* initial_block = (struct FMB*)memory_pool;
    initial_block->is_free = true;
    initial_block->size = POOL_SIZE - sizeof(struct FMB);
    initial_block->next = NULL;
}


void split(struct FMB* block, size_t size) {
    if (block->size >= 2 * size) {
        struct FMB* buddy = (struct FMB*)((char*)block + size + sizeof(struct FMB));
        buddy->is_free = true;
        buddy->size = block->size - size - sizeof(struct FMB);
        buddy->next = block->next;
        block->size = size;
        block->next = buddy;
        split(block, size); 
    }
}


void* myMalloc(size_t size) {
    
    size = (size < MIN_BLK_SIZE) ? MIN_BLK_SIZE : (1 << (int)ceil(log2((int)size)));

    struct FMB* current_block = (struct FMB*)memory_pool;

    while (current_block != NULL) {
        if (current_block->is_free && current_block->size >= size) {
            
            split(current_block, size);
            current_block->is_free = false;
            return (void*)((char*)current_block + sizeof(struct FMB));
        }
        current_block = current_block->next;
    }

   
    return NULL;
}


void myFree(void* ptr) {
    if (ptr == NULL) {
        return; 
    }

    struct FMB* block = (struct FMB*)((char*)ptr - sizeof(struct FMB));
    if (block >= (struct FMB*)memory_pool && block < (struct FMB*)(memory_pool + POOL_SIZE)) {
        
        block->is_free = true;
    
        while (block->next != NULL && block->next->is_free) {
            block->size += block->next->size + sizeof(struct FMB);
            block->next = block->next->next;
        }
    }
}

int main() {
    init_Allocator();

    
    void* ptr1 = myMalloc(64);
    printf("Memory allocated for address:  %p\n",ptr1);
    void* ptr2 = myMalloc(128);
    printf("Memory allocated for address:  %p\n",ptr2);
   
    myFree(ptr1);
    myFree(ptr2);
    printf("Freeed both the location.\n");

    return 0;
}



