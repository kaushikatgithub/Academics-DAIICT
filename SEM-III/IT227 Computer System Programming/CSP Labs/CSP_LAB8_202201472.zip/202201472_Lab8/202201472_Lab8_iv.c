#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>

char *vir_mem = NULL;
struct FMB *fList = NULL;
struct FMB *previousBlock = NULL;
int curr = 0;

struct FMB {
    size_t size;
    struct FMB *next;
};

void mymalloc(int n) {

    vir_mem = (char *)mmap(NULL, n * 1024, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

    if (vir_mem == MAP_FAILED) {
        perror("Failed to map!");
        exit(1);
    }

    fList = (struct FMB *)vir_mem;
    fList->size = n * 1024;
    fList->next = NULL;
}

void split(struct FMB *block, size_t size) {

    if (block->size > size + sizeof(struct FMB)) {
        struct FMB *newBlock = (struct FMB *)((char *)block + size + sizeof(struct FMB));
        newBlock->size = block->size - size - sizeof(struct FMB);
        newBlock->next = block->next;
        block->size = size;
        block->next = newBlock;
    }
}

void coalesce() {

    struct FMB *current = fList;
    struct FMB *prev = NULL;

    while (current && current->next) {

        if ((char *)current + current->size + sizeof(struct FMB) == (char *)current->next) {
            current->size += current->next->size + sizeof(struct FMB);
            current->next = current->next->next;
        }

        prev = current;
        current = current->next;
    }
}

void *bestFit(size_t size) {

    struct FMB *current = fList;
    struct FMB *bestFitBlock = NULL;
    size_t minSize = -1;

    while (current) {

        if (current->size >= size && current->size < minSize) {
            bestFitBlock = current;
            minSize = current->size;
        }

        current = current->next;
    }

    if (bestFitBlock) {

        if (bestFitBlock->size > size + sizeof(struct FMB)) {
            split(bestFitBlock, size);
        }

        return (char *)bestFitBlock + sizeof(struct FMB);
    }

    return NULL; // Memory allocation failed
}

void *worstFit(size_t size) {

    struct FMB *current = fList;
    struct FMB *worstFitBlock = NULL;
    size_t maxSize = 0;

    while (current) {

        if (current->size >= size && current->size > maxSize) {
            worstFitBlock = current;
            maxSize = current->size;
        }

        current = current->next;
    }

    if (worstFitBlock) {

        if (worstFitBlock->size > size + sizeof(struct FMB)) {
            split(worstFitBlock, size);
        }

        return (char *)worstFitBlock + sizeof(struct FMB);
    }

    return NULL;
}

void *firstFit(size_t size) {

    struct FMB *current = fList;
    struct FMB *prev = NULL;

    while (current) {

        if (current->size >= size) {

            if (current->size > size + sizeof(struct FMB)) {
                split(current, size);
            }

            if (prev) {
                prev->next = current->next;
            }else {
                fList = current->next;
            }

            return (char *)current + sizeof(struct FMB);
        }

        prev = current;
        current = current->next;
    }

    return NULL;
}

void *nextFit(size_t size) {

    struct FMB *current = previousBlock;
    struct FMB *prev = NULL;

    while (current) {

        if (current->size >= size) {

            if (current->size > size + sizeof(struct FMB)) {
                split(current, size);
            }

            if (prev) {
                prev->next = current->next;
            }else {
                fList = current->next;
            }

            previousBlock = current;
            return (char *)current + sizeof(struct FMB);
        }

        prev = current;
        current = current->next;

        if (!current && prev != previousBlock) {
            current = fList;
        }
    }

    return NULL;
}

void myfree(void *ptr) {

    if (ptr) {

        struct FMB *block = (struct FMB *)((char *)ptr - sizeof(struct FMB));
        block->next = fList;
        fList = block;

        if(curr+1 == 1) {
            printf("1st time freeing the memory.\n");
        }else if(curr+1 == 2) {
            printf("2nd time freeing the memory.\n");
        }else if(curr+1 == 3) {
            printf("3rd time freeing the memory.\n");
        }else {
            printf("%dth time freeing the memory.\n", ++curr);
        }
    
        printf("Freed %zu bytes.\n", block->size);
        printf("\n");
    }
}

int main() {

    int n = 16;
    mymalloc(n);
    char *m1 = (char *)bestFit(128);
    char *m2 = (char *)worstFit(256);
    char *m3 = (char *)firstFit(64);
    char *m4 = (char *)nextFit(512);

    myfree(m1);
    myfree(m2);
    myfree(m3);
    myfree(m4);

    return 0;
}
