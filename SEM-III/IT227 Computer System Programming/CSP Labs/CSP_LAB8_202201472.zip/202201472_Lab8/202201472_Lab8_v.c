#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/mman.h>

struct BuddyBlock {
    size_t size;
    struct BuddyBlock *next;
    int isFree;
};

char *vir_mem = NULL;
struct BuddyBlock *buddyTree = NULL;
int maxLevels;
int curr = 0;

void mymalloc() {

    vir_mem = (char *)mmap(NULL, 16 * 1024, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

    if (vir_mem == MAP_FAILED) {
        perror("Failed to map!");
        exit(1);
    }

    maxLevels = log2(16 * 1024);

    buddyTree = (struct BuddyBlock *)vir_mem;
    buddyTree->size = 16 * 1024;
    buddyTree->next = NULL;
    buddyTree->isFree = 1;
}

void split(struct BuddyBlock *block, int level) 
{
    if (level == 0) {
        return;
    }

    int blkSize = block->size;
    int halfSize = blkSize / 2;

    struct BuddyBlock *leftChild = (struct BuddyBlock *)((char *)block + halfSize);
    leftChild->size = halfSize;
    leftChild->next = block->next;
    leftChild->isFree = 1;

    block->size = halfSize;
    block->next = leftChild;

    split(leftChild, level - 1);
}

void *myMallocV3(size_t size) {

    int blkSize = 16 * 1024;
    int level = 0;
    while (blkSize > size && level < maxLevels) {
        printf("Search initiated for the block of %d.\n", blkSize);
        blkSize /= 2;
        level++;
    }

    struct BuddyBlock *current = buddyTree;
    while (current && !(current->isFree && current->size == blkSize)) {
        printf("Searching for %d sized memory.\n", blkSize);
        current = current->next;
    }

    if (current) {
        current->isFree = 0;
        printf("%zu bytes allocated.\n", current->size);
        return (void *)((char *)current + sizeof(struct BuddyBlock));
    }
    printf("%zu sized lblocks found.\n", size);

    return NULL;
}

void myFree(void *ptr) {

    if (!ptr) {
        return;
    }

    struct BuddyBlock *block = (struct BuddyBlock *)((char *)ptr - sizeof(struct BuddyBlock));

    block->isFree = 1;
    printf("Freeing for the %dth time.\n",++curr);
    printf("Freeing up %zu bytes\n.", block->size);
    printf("\n");

    int level = 0;
    while (level < maxLevels) {

        int blkSize = block->size;
        int buddyOffset = (int)((char *)block - (char *)buddyTree);
        int buddyIndex = buddyOffset / blkSize;

        struct BuddyBlock *buddy = buddyTree + buddyIndex;

        if (buddy->isFree && buddy->size == blkSize && (buddyOffset / (2 * blkSize)) % 2 == 1) {
            
            if (buddyIndex % 2 == 0) {
                block = buddy;
            }

            if (block->next == buddy) {
                block->next = buddy->next;
            }else {

                struct BuddyBlock *current = block->next;
                while (current->next != buddy) {
                    current = current->next;
                }
                current->next = buddy->next;
            }

            block->size *= 2;
            level++;
        }else {
            break;
        }
    }
}

int main() {
    
    mymalloc();

    char *mem1 = (char *)myMallocV3(128);
    char *mem2 = (char *)myMallocV3(256);

    myFree(mem1);
    myFree(mem2);

    return 0;
}

