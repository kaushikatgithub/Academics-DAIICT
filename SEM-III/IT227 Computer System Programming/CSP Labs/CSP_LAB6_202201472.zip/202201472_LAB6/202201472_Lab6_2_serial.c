#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <math.h>
#include <stdint.h>
#include <sys/time.h>

#define row 5
#define col 5

int mat[row][col];

uint64_t get_gtod_clock_time() {
    struct timeval tv;
    if (gettimeofday(&tv, NULL) == 0) { return (uint64_t)(tv.tv_sec * 1000000 + tv.tv_usec); }
    else { return 0; }
}

int main() {
    uint64_t start_time_value, end_time_value, time_diff;
    start_time_value = get_gtod_clock_time();
    int r = row, c = col;
    int sum = 0;
    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
            scanf("%d", &mat[i][j]);
            sum += mat[i][j];
        }
    }
    printf("Total sum : %d\n", sum);
    end_time_value = get_gtod_clock_time();
    time_diff = end_time_value - start_time_value;
    printf("%lu PRIu64 \n", time_diff);
}
