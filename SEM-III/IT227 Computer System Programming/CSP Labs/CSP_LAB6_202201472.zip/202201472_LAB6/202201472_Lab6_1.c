#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <math.h>

double sroot[100] = {0};

void *sqr_root(void *arg) {
    int *a = arg;
    int v = *a;
    for (int i = 0; i < 10; i++) {
        sroot[v] = sqrt(v);
        v++;
    }

    int *ret2 = (int *) malloc(sizeof(int));
    *ret2 = 0;
    pthread_exit((void *) ret2);
}

int main(void) {
    int err;
    pthread_t tid[10];
    printf("Main thread is %u \n", (unsigned int) pthread_self());

    int *tret[10];
    int array[10];
    int pass = 0;
    for (int i = 0; i < 10; i++) {
        array[i] = pass;
        pass += 10;
    }

    for (int i = 0; i < 10; i++) {
        err = pthread_create(&tid[i], NULL, sqr_root, (void *) &array[i]);
        if (err != 0) { printf("cant create thread %d: %s\n", i, strerror(err)); }
        else { printf("child thread %u is created\n", (unsigned int) tid[i]); }

    }

    for (int i = 0; i < 10; i++) {
        printf("Waiting for computation to finish\r");
        err = pthread_join(tid[i], (void **) &tret[i]);

        if (err != 0) { printf("cant join with thread1: %s\n", strerror(err)); }

        printf("child thread %u exit code %d\n", (unsigned int) tid[i], (int) (*tret[i]));
        free(tret[i]);
    }
    for (int i = 0; i < 100; i++) {
        printf("square root of %d is %f\n", i, sroot[i]);
    }
}
