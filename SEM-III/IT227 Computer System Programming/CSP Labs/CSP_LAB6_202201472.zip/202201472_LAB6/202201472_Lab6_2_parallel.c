#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <math.h>
#include <stdint.h>
#include <sys/time.h>

#define row 5
#define col 5

struct imp {
    int s;
    int cnt;
};

int mat[row][col];

uint64_t get_gtod_clock_time() {
    struct timeval tv;
    if (gettimeofday(&tv, NULL) == 0)
        return (uint64_t)(tv.tv_sec * 1000000 + tv.tv_usec);
    else
        return 0;
}


void *mat_sum(void *arg) {
    struct imp *p = arg;
    int sum = 0;
    int ind = p->s;
    printf("This thread will handle from %d to %d\n", ind, ind + p->cnt - 1);
    for (int i = 0; i < p->cnt; i++) {
        for (int j = 0; j < col; j++) {
            sum += mat[ind][j];
        }
        ind++;
    }
    int *ret2 = (int *) malloc(sizeof(int));
    *ret2 = sum;
    pthread_exit((void *) ret2);
}

int main() {
    uint64_t start_time_value, end_time_value, time_diff;
    start_time_value = get_gtod_clock_time();
    int err, rmd, each, a, thread;
    int r = row, c = col;
    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
            scanf("%d", &mat[i][j]);
        }
    }

    printf("Enter number of threads you want to create(must be < no of rows): ");
    scanf("%d", &thread);
    int *tret[thread];
    each = r / thread;
    rmd = r % thread;
    pthread_t tid[thread];
    struct imp arr[thread];
    a = 0;
    for (int i = 0; i < thread; i++) {
        arr[i].s = a;
        arr[i].cnt = each;

        a += each;
        if (rmd > 0) {
            arr[i].cnt++;
            a++;
            rmd--;
        }
    }
    for (int i = 0; i < thread; i++) {
        err = pthread_create(&tid[i], NULL, mat_sum, (void *) &arr[i]);
        if (err != 0) { printf("Can't create thread! %d: %s\n", i, strerror(err)); }
        else { printf("Child thread %u is created\n", (unsigned int) tid[i]); }
    }
    int ans = 0;
    for (int i = 0; i < thread; i++) {
        err = pthread_join(tid[i], (void **) &tret[i]);
        if (err != 0) { printf("Can't join with thread1: %s\n", strerror(err)); }
        ans += (int) (*tret[i]);
        free(tret[i]);
    }
    printf("Total sum : %d\n", ans);
    end_time_value = get_gtod_clock_time();
    time_diff = end_time_value - start_time_value;
    printf("%lu PRIu64 \n", time_diff);
}
