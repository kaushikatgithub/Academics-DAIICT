#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#define PAGE_SIZE 4096
#define VIRTUAL_ADDRESS_SPACE_SIZE 4 * 1024 * 1024

typedef struct
{
	int page_frame_number;
	int valid_bit;
} page_table_entry;

page_table_entry *page_table;

void init_page_table()
{
	page_table = (page_table_entry *)mmap(NULL, VIRTUAL_ADDRESS_SPACE_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
	if (page_table == MAP_FAILED)
	{
		perror("mmap");
		exit(1);
	}
	for (int i = 0; i < VIRTUAL_ADDRESS_SPACE_SIZE / PAGE_SIZE; i++)
	{
		page_table[i].valid_bit = 0;
	}
	page_table[0].valid_bit = 1;
	for (int i = 1; i <= 15; i++)
	{
		page_table[i].valid_bit = 1;
	}
	for (int i = 16; i <= 31; i++)
	{
		page_table[i].valid_bit = 1;
	}
}

int get_physical_address(int virtual_address)
{
	if (virtual_address < 0 || virtual_address >= VIRTUAL_ADDRESS_SPACE_SIZE)
	{
		return -1;
	}
	page_table_entry *page_table_entry = &page_table[virtual_address / PAGE_SIZE];
	if (!page_table_entry->valid_bit)
	{
		return -1;
	}
	int page_frame_number = page_table_entry->page_frame_number;
	int physical_address = page_frame_number * PAGE_SIZE + (virtual_address % PAGE_SIZE);
	return physical_address;
}

void generate_and_print_virtual_addresses()
{
	for (int i = 0; i < VIRTUAL_ADDRESS_SPACE_SIZE; i += 1024)
	{
		int virtual_address = i;
		int physical_address = get_physical_address(virtual_address);
		if (physical_address != -1)
		{
			printf("Virtual address: %x, Physical address: %x\n", virtual_address, physical_address);
		}
	}
}

int main()
{
	init_page_table();
	generate_and_print_virtual_addresses();
	munmap(page_table, VIRTUAL_ADDRESS_SPACE_SIZE);
	printf("Page table size: %d bytes.\n", VIRTUAL_ADDRESS_SPACE_SIZE);
	printf("Page table entry size: %ld bytes.\n", sizeof(page_table_entry));
	return 0;
}
