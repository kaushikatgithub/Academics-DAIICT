#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define NUM_REFERENCES 1024 * 1024
#define PAGE_SIZE_1KB 1024
#define PAGE_SIZE_4KB 4096

void linearAccess(int numPages, int pageSize, int numReferences)
{
	char *memory = malloc(numPages * pageSize);
	if (memory == NULL)
	{
		perror("Memory allocation failed!");
		return;
	}
	clock_t start_time = clock();
	for (int i = 0; i < numReferences; i++)
	{
		int page = i % numPages;
		char value = memory[page * pageSize];
	}
	clock_t end_time = clock();
	free(memory);
	double elapsed_time = (double)(end_time - start_time) / CLOCKS_PER_SEC;
	printf("Number of Pages Referenced: %d\n", numPages);
	printf("Time Elapsed: %.6f seconds\n", elapsed_time);
}

int main()
{
	printf("With TLB:\n");
	int numReferencesPerPage = NUM_REFERENCES / 4;
	linearAccess(4, PAGE_SIZE_1KB, numReferencesPerPage);
	linearAccess(16, PAGE_SIZE_1KB, numReferencesPerPage);
	linearAccess(64, PAGE_SIZE_1KB, numReferencesPerPage);
	linearAccess(128, PAGE_SIZE_1KB, numReferencesPerPage);
	
	printf("\nWithout TLB:\n");
	linearAccess(4, PAGE_SIZE_4KB, numReferencesPerPage);
	linearAccess(16, PAGE_SIZE_4KB, numReferencesPerPage);
	linearAccess(64, PAGE_SIZE_4KB, numReferencesPerPage);
	linearAccess(128, PAGE_SIZE_4KB, numReferencesPerPage);
	return 0;
}
