#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{

    if (argc != 3)
    {
        fprintf(stderr, "Usage: %s <filename> <line_number>\n", argv[0]);
        return 1;
    }

    char *filename = argv[1];
    int line_number = atoi(argv[2]);

    FILE *file = fopen(filename, "r");

    if (file == NULL)
    {
        perror("fopen");
        return 1;
    }

    char buffer[1024];
    int current_line = 0;

    while (fgets(buffer, sizeof(buffer), file) != NULL)
    {
        current_line++;
        if (current_line == line_number)
        {
            printf("%s", buffer);
            break;
        }
    }

    fclose(file);

    return 0;
}
