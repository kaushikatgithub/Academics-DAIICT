#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MSGLEN 128

int main()
{
    char *questions[] = {"Quit", "In which college are you studing?", "Which course are you studying?", "What do you do in your fun time?"};
    char *answers[] = {"Quit", "DAIICT", "Computer Systems Programming", "Watching movies"};

    int fd1[2];
    int fd2[2];
    if (pipe(fd1) == -1 || pipe(fd2) == -1)
    {
        perror("pipe");
        exit(1);
    }

    pid_t child_pid = fork();

    if (child_pid == -1)
    {
        perror("fork");
        exit(1);
    }

    if (child_pid == 0)
    {
        close(fd1[1]);
        close(fd2[0]);
        char message[MSGLEN];
        int que;

        while (1)
        {
            int bytesRead = read(fd1[0], message, MSGLEN);
            if (bytesRead < 0)
            {
                perror("read");
                exit(1);
            }
            que = atoi(message);
            if (que == 0)
            {
                write(fd2[1], answers[0], strlen(answers[0]) + 1);
                close(fd1[0]);
                close(fd2[1]);
                exit(0);
            }
            if (que >= 1 && que <= 3)
            {
                write(fd2[1], answers[que], strlen(answers[que]) + 1);
            }
        }
    }
    else
    {
        close(fd1[0]);
        close(fd2[1]);
        char message[MSGLEN];
        int que;
        while (1)
        {
            printf("Enter question number (1-3) or 0 to quit: ");
            scanf("%d", &que);

            if (que < 0 || que > 3)
            {
                printf("Invalid question number. Try again.\n");
                continue;
            }
            sprintf(message, "%d", que);
            write(fd1[1], message, strlen(message) + 1);
            if (que == 0)
            {
                int bytesRead = read(fd2[0], message, MSGLEN);
                if (bytesRead > 0)
                {
                    printf("Answer from child: %s\n", message);
                }
                close(fd1[1]);
                close(fd2[0]);
                wait(NULL);
                exit(0);
            }
            else
            {
                int bytesRead = read(fd2[0], message, MSGLEN);
                if (bytesRead > 0)
                {
                    printf("Answer from child: %s\n", message);
                }
            }
        }
    }

    return 0;
}
