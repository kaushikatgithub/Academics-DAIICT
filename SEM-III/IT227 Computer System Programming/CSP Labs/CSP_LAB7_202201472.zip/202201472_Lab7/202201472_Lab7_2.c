// Header file section
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define col 3
#define row 5

pthread_rwlock_t rw_lock;
pthread_mutex_t mutex;

int ptable[row][col];
int ct = 0;

// Function to check wether the P-table is full or not
int isPTableFull() {

	if (ct == row)
		return 1;
	return 0;
}

int checkProcessid(int pid) {

	for (int i = 0; i < row; i++) {
		if (ptable[i][0] == pid)
			return 1;
	}
	return 0;
}

int LF() {

	int min = ptable[0][2];
	int flag = 0;

	for (int i = 1; i < row; i++) {

		if (min > ptable[i][2]) {
			min = ptable[i][2];
			flag = i;
		}
	}
	return flag;
}

// Reader function
void Reader(void *arg) {

	pthread_rwlock_rdlock(&rw_lock);

	printf("***Reading***\n");
	int pid;
	random_num:
		pid = rand() % 10;
		if (!checkProcessid(pid))
			goto random_num;

	pthread_rwlock_unlock(&rw_lock);
	pthread_mutex_lock(&mutex);
	ptable[pid][2]++;
	pthread_mutex_unlock(&mutex);
}

// Writer function
void Writer(void *arg) {

	printf("***Writing***\n");
	int processId = rand() % 10;
	int pageNo = (rand() % 1000) + 50;
	int frequency = 1;
	pthread_mutex_lock(&mutex);
	
	if (!isPTableFull() && ct < 5) {
		ptable[ct][0] = processId;
		ptable[ct][1] = pageNo;
		ptable[ct][2] = frequency;
		ct++;
	}else {
		printf("Table is full!\n");
		int lfIndex = LF();

		for (int i = 0; i < 5; i++) {
			printf("%d %d %d \n", ptable[i][0], ptable[i][1], ptable[i][2]);
		}
		printf("--------------------\n");
		
		printf("PID =  %d has least frequency.\n", ptable[lfIndex][0]);
		ptable[lfIndex][0] = processId;
		ptable[lfIndex][1] = pageNo;
		ptable[lfIndex][2] = frequency;
		
		for (int i = 0; i < 5; i++) {
			printf("%d %d %d \n", ptable[i][0], ptable[i][1], ptable[i][2]);
		}
		
		printf("--------------------\n");
	}
	pthread_mutex_unlock(&mutex);
}

int main() {

	int res;
	pthread_t threads[15];
	res = pthread_mutex_init(&mutex, NULL);

	// Thread Creation
	for (int i = 0; i < 15; i++) {
		if (i % 2 == 0)
			pthread_create(&threads[i], NULL, (void *)Writer, NULL);
		else
			pthread_create(&threads[i], NULL, (void *)Reader, NULL);
		pthread_join(threads[i], NULL);
	}

	res = pthread_mutex_destroy(&mutex);
	exit(0);
}
