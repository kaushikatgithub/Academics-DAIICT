// Header file section
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#define MAX_BUF_SIZE 1024

char filebuf[MAX_BUF_SIZE];
char printbuf[MAX_BUF_SIZE];

int filebuf_filled = 0;
int printbuf_filled = 0;

pthread_mutex_t file_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t print_mutex = PTHREAD_MUTEX_INITIALIZER;

pthread_cond_t file_full = PTHREAD_COND_INITIALIZER;
pthread_cond_t file_empty = PTHREAD_COND_INITIALIZER;
pthread_cond_t print_full = PTHREAD_COND_INITIALIZER;
pthread_cond_t print_empty = PTHREAD_COND_INITIALIZER;

void *read_file(void *arg) {

    FILE *file = fopen("file1.txt", "r");

    if (!file) {
        perror("File open error");
        exit(1);
    }

    while (1) {

        pthread_mutex_lock(&file_mutex);

        while (filebuf_filled == 1) {
            pthread_cond_wait(&file_empty, &file_mutex);
        }

        size_t bytes_read = fread(filebuf, 1, sizeof(filebuf), file);

        if (bytes_read == 0) {
            pthread_mutex_unlock(&file_mutex);
            break;
        }

        filebuf_filled = 1;
        pthread_cond_signal(&file_full);
        pthread_mutex_unlock(&file_mutex);
    }

    fclose(file);
    pthread_exit(NULL);
}

void *copy_to_printbuf(void *arg) {

    while (1) {
        pthread_mutex_lock(&file_mutex);

        while (filebuf_filled == 0) {
            pthread_cond_wait(&file_full, &file_mutex);
        }

        pthread_mutex_lock(&print_mutex);

        while (printbuf_filled == 1) {
            pthread_cond_wait(&print_empty, &print_mutex);
        }

        // Copy from filebuf to printbuf
        memcpy(printbuf, filebuf, sizeof(filebuf));
        filebuf_filled = 0;
        printbuf_filled = 1;

        pthread_cond_signal(&file_empty);
        pthread_cond_signal(&print_full);

        pthread_mutex_unlock(&print_mutex);
        pthread_mutex_unlock(&file_mutex);
    }

    pthread_exit(NULL);
}

void *print_content(void *arg) {
    while (1) {
        pthread_mutex_lock(&print_mutex);

        while (printbuf_filled == 0) {
            pthread_cond_wait(&print_full, &print_mutex);
        }

        // Print the content to standered output
        printf("%s", printbuf);
        printbuf_filled = 0;

        pthread_cond_signal(&print_empty);
        pthread_mutex_unlock(&print_mutex);
    }

    pthread_exit(NULL);
}

int main() {
    pthread_t thread1, thread2, thread3;

    pthread_create(&thread1, NULL, read_file, NULL);
    pthread_create(&thread2, NULL, copy_to_printbuf, NULL);
    pthread_create(&thread3, NULL, print_content, NULL);

    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);
    pthread_join(thread3, NULL);

    return 0;
}
