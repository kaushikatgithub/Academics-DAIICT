#include <stdio.h>
#include <signal.h>
#include <unistd.h>
int main(){
  int pid;
  printf("Enter process id: ");
  scanf("%d",&pid);
  printf("Enter your choice:\n1.Send to process\n2.Send to group\n");
  int choice;
  printf("Enter your choice: ");
  scanf("%d",&choice);
  if(choice==1){
    printf("Sending signal to process only.\n");
    kill(pid,SIGINT);
  }
  else{
    printf("Sending signal to group!!\n");
    kill(-pid,SIGINT);
  }
  printf("Signal sent!!\n");
}
