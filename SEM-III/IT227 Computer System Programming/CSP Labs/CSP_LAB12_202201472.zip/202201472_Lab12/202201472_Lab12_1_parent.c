#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <signal.h>
#define msglen 100

int q;
char *qst[] = {"quit", "You study in which university?", "what courses are you studying?", "what is your area of interest ?"};
char *ans[] = {"quit", "DA-IICT", "Computer System Programming", "Embeded System"};
int fd1[2];
int child;
char mesg[100];
int bytes = 0;

void sig_handler()
{
  char mesg[msglen];
  int bytes;
  bytes = read(fd1[0], mesg, msglen);

  if (bytes <= 0)
  {
    printf("Question not received!!\n");
  }

  int q = atoi(mesg);
  printf("Question received by child is: %s\n", qst[q]);
  if (q == 0)
  {
    printf("Quiting, Good Bye\n");
    close(fd1[0]);
    close(fd1[1]);
    kill(getppid(), SIGUSR2);
    exit(1);
  }

  if (q >= 1 && q <= 3)
  {
    write(fd1[1], ans[q], strlen(ans[q]) + 1);
  }
  kill(getppid(), SIGUSR2);
}

void parent_fnctn()
{

  printf("Enter your question number : ");
  scanf("%d", &q);

  if (q < 0 || q > 3)
  {
    printf("invalid num\n");
    return;
  }

  sprintf(mesg, "%d", q);
  write(fd1[1], mesg, strlen(mesg) + 1);
  kill(child, SIGUSR1);
}

void sig_handler2()
{

  if (q == 0)
  {
    printf("Waiting for child to terminate\n");
    wait(NULL);
    close(fd1[0]);
    close(fd1[1]);
    printf("Child has exited,now parent exiting too!!\n");
    exit(1);
  }

  bytes = read(fd1[0], mesg, msglen);
  if (bytes <= 0)
  {
    printf("No message received!!\n");
    return;
  }

  printf("Answer received: %s\n", mesg);
}
int main()
{

  pipe(fd1);
  child = fork();
  if (child == -1)
  {
    perror("fork");
    exit(1);
  }
  
  if (child == 0)
  {
    signal(SIGUSR1, sig_handler);
    while (1)
    {
      pause();
    }
  }
  else
  {
    int bytes;
    while (1)
    {
      parent_fnctn();
      signal(SIGUSR2, sig_handler2);
      pause();
    }
  }

  return 0;
}
