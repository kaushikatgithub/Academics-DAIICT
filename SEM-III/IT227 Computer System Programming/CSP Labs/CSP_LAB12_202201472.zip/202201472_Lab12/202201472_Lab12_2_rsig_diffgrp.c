#include <stdio.h>
#include <signal.h>
#include <unistd.h>

void signal_handler()
{
	printf("Process id %d received SIGINT signal\n", getpid());
}

int main(void)
{
	signal(SIGINT, signal_handler);
	if (fork() ==0)	
	{
		printf("Child pid: %d   Group id: %d\n",getpid(),getpgid(0));
		setpgid(getpid(), 0);	
		printf("Child pid: %d   Group id: %d\n",getpid(),getpgid(0));
	}
	else{		
		printf("Parent pid: %d   Group id: %d\n",getpid(),getpgid(0));
	}	
	pause();	

}
