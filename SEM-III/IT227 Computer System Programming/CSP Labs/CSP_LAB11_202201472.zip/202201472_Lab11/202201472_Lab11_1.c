#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>

void alarm_handler(){
    printf("It took too long to enter the string.\n");
    exit(-1);
}

int main(){
    char str[2000];
    alarm(10);
    signal(SIGALRM,alarm_handler);
    printf("Enter the string: \n");
    scanf("%s",str);
    alarm(0);
    printf("The string is \n");
    printf("%s",str);
    return 0;
}