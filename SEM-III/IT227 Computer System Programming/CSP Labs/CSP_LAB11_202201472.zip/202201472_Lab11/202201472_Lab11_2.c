#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include<sys/wait.h>

pid_t pid;

void parent_handler(){
    printf("Child process terminated with SIGINT.\n");
    kill(pid,SIGINT);
}

int main(){
    pid = fork();
    if(pid==0){
        sleep(10);
        printf("Child process is terminating...\n");
        exit(1);
    }
    else{
        alarm(5);
        signal(SIGALRM,parent_handler);
        int status;
        wait(&status);
        if(WIFEXITED(status)){
            printf("Parent process terminating...\n");
        }
    }
    return 0;
}
