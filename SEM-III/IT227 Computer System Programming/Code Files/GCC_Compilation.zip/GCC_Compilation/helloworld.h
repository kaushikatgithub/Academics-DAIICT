//#define intel 1
#include <strings.h>