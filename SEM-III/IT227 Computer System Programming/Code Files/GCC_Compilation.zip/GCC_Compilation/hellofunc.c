#include <stdio.h> 
//#include "hellomake.h"
void myPrintHelloMake(void)
{
	printf("Howdy makefiles!\n"); 
	return; 
}

