double sub(double a, double b)
{
	return b-a;
}