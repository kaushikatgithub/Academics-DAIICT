#include "hellomake.h"
int main() { 
	// call function in another file
	myPrintHelloMake(); 
	return(0); 
}
