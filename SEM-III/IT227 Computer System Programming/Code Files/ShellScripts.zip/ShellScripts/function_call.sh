#!/bin/bash
source function.sh
Hello abc def xyz