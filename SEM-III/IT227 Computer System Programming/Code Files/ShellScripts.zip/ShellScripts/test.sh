#!/bin/bash
echo "File name: $0"
echo "First command line argument is: $1"
echo "Second command line argument is: $2"
echo "No of argument is: $#"