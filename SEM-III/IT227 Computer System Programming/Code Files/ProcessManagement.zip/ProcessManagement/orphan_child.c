#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main(void)
{
	int pid;
    printf("Im the original process with PID %d and PPID %d. \n", getpid(), getppid() );
    pid = fork(); /* Duplicate. Child and parent continue from here */
    if ( pid!= 0 ) /* pid is non-zero, so I must be the parent --> Parent and Child execute from this point */
    {
        printf("Im the parent process with PID %d and PPID %d. \n", getpid(), getppid() );
        printf("My childs PID is %d \n", pid );
		sleep(5);
    }
	else /* pid is zero, so I must be the child */
    {
		sleep(15); // add sleep so child process will terminate later then parent 
        printf("Im the child process with PID %d and PPID %d. \n", getpid(), getppid() );
    }
    printf("PID %d terminates. \n", getpid() ); /* Both processes execute this */
}
