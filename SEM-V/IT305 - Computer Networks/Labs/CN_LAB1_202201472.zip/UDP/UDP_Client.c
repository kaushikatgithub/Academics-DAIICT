//Client side C/C++ program to demonstrate Socket programming 
#include <stdio.h> 
#include <stdlib.h>
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <unistd.h> 
#include <string.h> 
#define PORT 8080 
#define MAX 1024
#define ERROR 1

// Constructing 32-bit checkSum from provided message
// Error determines whether we should include error while constructing checkSum or not
unsigned int getCheckSum(const char *msg,short error){
    
    long long sum = 0;
    if(error) sum = 22;
    int n = strlen(msg);

    for(int i=0 ; i<n ; i++){
        sum += msg[i];
    }

    while(sum >> 32){
        long long carry = (sum>>32);
        long long mask = (1ll<<33)-1;

        sum = sum & mask;
        sum += carry;
    }
    return (unsigned int)sum;
}

// Generating 32 bit binary string representation of a number
char* getBinaryStr(unsigned int num){

    // Dynamically allocating the memory for string 
    char* str=(char *)calloc(sizeof(char),33);
    for(int i=0 ; i<33 ; i++){
        str[i] = '0';
    }
    
    int n = 31;
    while(num) {
    
        str[n] = (num & 1) + '0';
        num = (num >> 1);
        n -= 1;
    }

    str[32] = '\0';
    return str;
}

// Appending checkSum to the actual message
char* appendCheckSum(char* msg) {

    char* checkSum = getBinaryStr(getCheckSum(msg, !ERROR));
    int msgLen = strlen(msg);
    int checkSumLen = strlen(checkSum);
    char* ans = (char*)calloc(sizeof(char), msgLen + checkSumLen + 3);

    int i = 0;
    while(i < msgLen){
        ans[i] = msg[i];
        i++;
    }

    // Separating the message from checkSum using "##"
    ans[i] ='#'; i++;
    ans[i] ='#'; i++;

    while(i < msgLen + checkSumLen + 2){
        ans[i] = checkSum[i-msgLen-2];
        i++;
    }

    ans[i] = '\0';
    return ans;
}

int main(int argc, char const *argv[]) { 

	int sock = 0, valread; 
	struct sockaddr_in serv_addr,server_info; 
	char* msg = "Hi there, i am kaushik prajapati\n";
	char buffer[MAX] ={0}; 

	if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) { 
		printf("\nSocket creation error\n"); 
		return -1; 
	} 
	serv_addr.sin_family = AF_INET; // match the socket() call
	serv_addr.sin_port = htons(PORT); // specify port to listen on 

	// Convert IPv4 and IPv6 addresses from text to binary form 
	if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) { 
		printf("\nInvalid address/Address not supported\n"); 
		return -1;
	}    
	
    	// Adding checkSum to the message
    	char *codedMsg = appendCheckSum(msg);

    	// Sending the message to server
	sendto(sock, codedMsg, strlen(codedMsg), MSG_CONFIRM, (const struct sockaddr*)&serv_addr, sizeof(serv_addr)); 

    	int server_info_len = 0;
    	//Recieving message for the server
    	int n = recvfrom(sock, buffer, MAX, MSG_WAITALL, (struct sockaddr *)&server_info, &server_info_len);
    	buffer[n] = '\0';

    	printf("Reply from server: %s",buffer);
    	printf("Exiting from Client now.\n");
    	close(sock);
    	return 0; 
}
