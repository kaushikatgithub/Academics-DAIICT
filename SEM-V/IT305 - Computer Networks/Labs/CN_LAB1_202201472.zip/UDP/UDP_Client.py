from socket import *

server_name = "localhost"
server_port = 8000

client_socket = socket(AF_INET, SOCK_DGRAM)
message = "Hello, I am Rahul Prajapati!"

client_socket.sendto(message.encode(), (server_name, server_port))

server_message, server_address = client_socket.recvfrom(2048)
print(server_message.decode())

client_socket.close()