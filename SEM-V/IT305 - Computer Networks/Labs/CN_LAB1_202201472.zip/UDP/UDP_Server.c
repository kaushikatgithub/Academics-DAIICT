// Serverside C/C++ program to demonstrate Socket programming 
#include <unistd.h> 
#include <stdio.h> 
#include <stdlib.h>
#include <asm-generic/socket.h>
#include <sys/socket.h> 
#include <stdlib.h> 
#include <netinet/in.h> 
#include <string.h> 
#define PORT 8080 
#define MAX 1024

// Constructing 32-bit checkSum from provided message
// Error determines whether we should include error while constructing checkSum or not
unsigned int getCheckSum(const char *msg){
    long long sum=0;
    int n=strlen(msg);

    for(int i=0;i<n;i++){
        sum+=msg[i];
    }

    while(sum >> 32){
        long long carry=(sum>>32);
        long long mask=(1ll<<33)-1;

        sum=sum & mask;
        sum+=carry;
    }
    return (unsigned int)sum;
}

// Generating 32 bit binary string representation of a number
char* getBinaryStr(unsigned int num){
    // Dynamically allocating the memory for string 
    char* str=(char *)calloc(sizeof(char),33);
    for(int i=0;i<33;i++){
        str[i]='0';
    }
    
    int n=31;

    while(num){
        str[n]=(num&1)+'0';
        num=num>>1;
        n-=1;
    }

    str[32]='\0';
    return str;
}

// Verifying CheckSum of the message
unsigned int verifyCheckSum(char* msg, char* checkSum){
    
    char* calculatedChekcSum = getBinaryStr(getCheckSum(msg));

    unsigned int errorBits=0;
    for(int i=0;i<32;i++){
        errorBits+=(calculatedChekcSum[i]!=checkSum[i]);
    }

    return errorBits;
}

// Appending checkSum to the actual message
char* appendCheckSum(char* msg) {
    char* checkSum=getBinaryStr(getCheckSum(msg));

    int msgLen=strlen(msg);
    int checkSumLen=strlen(checkSum);
    char* ans=(char*)calloc(sizeof(char),msgLen+checkSumLen+3);

    int i=0;
    while(i<msgLen){
        ans[i]=msg[i];
        i++;
    }

    // Separating the message from checkSum using "##"
    ans[i]='#';i++;
    ans[i]='#';i++;

    while(i<msgLen+checkSumLen+2){
        ans[i]=checkSum[i-msgLen-2];
        i++;
    }

    ans[i]='\0';
    return ans;
}

int main(int argc, char const *argv[]) { 
	int server_fd; 
	struct sockaddr_in address,client_info; 
	int opt = 1; 

	char *exit_msg = "exit\n";	
	char buffer[MAX]={0};
	
	// Creating socket file descriptor 
	if ((server_fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) { 
		perror("socket failed"); 
		exit(EXIT_FAILURE); 
	} 
	
	// Forcefully attaching socket to the port 8080 - For address reuse 
	if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt))) { 
		perror("setsockopt"); 
		exit(EXIT_FAILURE); 
	} 
	
	address.sin_family = AF_INET; // match the socket() call 
	address.sin_addr.s_addr = INADDR_ANY; // bind to any local address 
	address.sin_port = htons(PORT);   // specify port to listen on 
	
	
    // Binding the socket to specified IP address and port
	if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) { 
		perror("bind failed"); 
		exit(EXIT_FAILURE); 
	}

    int client_info_len=sizeof(client_info);
    
    //Recieving message for the client
    int n=recvfrom(server_fd,buffer,MAX,MSG_WAITALL,(struct sockaddr *)&client_info,&client_info_len);
    buffer[n]='\0';

    char* msg = strtok(buffer, "##");
    char* checkSum=strtok(NULL,"##");

    // Checking the checkSum to see if we got any error or not
    unsigned int errorBits = verifyCheckSum(msg, checkSum);
    if(errorBits == 0){
        printf("Msg received from client: %s",buffer);

        char *confirm_msg="Yes, connection confirmed\n";

        // Sending the respone to client
        sendto(server_fd,confirm_msg,strlen(confirm_msg),MSG_CONFIRM,(struct sockaddr*)&client_info,client_info_len);

    }
    else{
        printf("Errorneous message\n");

        char *error_msg="Message received in error!\n";

        // Sending the respone to client
        sendto(server_fd,error_msg,strlen(error_msg),MSG_CONFIRM,(struct sockaddr*)&client_info,client_info_len);
    }
   
	printf("Exiting from Server now.\n");
    	close(server_fd);
	return 0; 
}
