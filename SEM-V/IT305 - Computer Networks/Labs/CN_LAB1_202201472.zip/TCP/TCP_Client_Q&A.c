//Client side C/C++ program to demonstrate Socket programming 
#include <stdio.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <unistd.h> 
#include <string.h> 
#define PORT 8080
#define MAX 1024


int main(int argc, char const *argv[]) { 

	int sock = 0, valread; 
	struct sockaddr_in serv_addr; 
	char *exit_msg = "exit\n";
	char msg[MAX] = {0};
	char buffer[MAX] = {0}; 
	
	// Creating socket file descriptor 
	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) { 
		printf("\nSocket creation error\n"); 
		return -1; 
	} 
	// 
	serv_addr.sin_family = AF_INET; 	// match the socket() call 
	serv_addr.sin_port = htons(PORT); 	// specify port to listen on
	
	// Convert IPv4 and IPv6 addresses from text to binary form 
	if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) { 
		printf("\nInvalid address/Address not supported\n"); 
		return -1;
	} 
	
	// Sending connection request to the server
	if (connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) { 
		printf("\nConnection Failed\n"); 
		return -1; 
	} 
	
	// Opening the file for Q&A
	FILE *file = NULL;
	if((file = fopen("questions.txt", "r")) == NULL){
		printf("Error in opening a file!\n");
		return -1;
	}
	
	printf("\n");
	// Client-Server Q&A Process
	while (1) { 
	
		memset(msg, 0, MAX); // clearing buffer
		fgets(msg, MAX, file); // Reading Question from file
		
		if (!strcmp(msg, exit_msg)) { 
			send(sock, msg, strlen(msg), 0);
			close(sock); 
			break;
		}
		
		printf("Asked Question: %s", msg);
		send(sock, msg, strlen(msg), 0); // Sending the Question
		memset(buffer, 0, MAX); // clearing buffer
		valread = read(sock, buffer, MAX); // Reading the answer from server
		printf("Answer From Server: %s", buffer); 
		getchar();
	} 
	
	printf("Exiting from Client now.\n");
	// closing the file
	fclose(file);
	return 0; 
}
