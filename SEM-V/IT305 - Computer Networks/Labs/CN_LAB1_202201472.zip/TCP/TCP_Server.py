from socket import *

server_port = 8000
server_socket = socket(AF_INET, SOCK_STREAM)
server_socket.bind(("", server_port))
server_socket.listen(1)
print("Server is ready to receive.")

while True:
    client_socket, addr = server_socket.accept()
    message = client_socket.recv(1024)
    msg = "Hello from server"
    print(message.decode())
    client_socket.send(msg.encode())
    client_socket.close()