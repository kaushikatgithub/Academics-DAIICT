// Serverside C/C++ program to demonstrate Socket programming 
#include <unistd.h> 
#include <stdio.h> 
#include <sys/socket.h>
#include <asm-generic/socket.h>
#include <stdlib.h> 
#include <netinet/in.h> 
#include <string.h> 
#define PORT 8080 
#define MAX 1024

int main(int argc, char const *argv[]) { 
 
	int server_fd, new_socket, valread; 
	struct sockaddr_in address; 
	int opt = 1; 
	int addrlen = sizeof(address);
	char *exit_msg = "exit\n";	
	char buffer[MAX] = {0};
	char answer[MAX] = {0};
	
	// Creating socket file descriptor 
	if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) { 
		perror("socket failed"); 
		exit(EXIT_FAILURE); 
	} 
	
	// Forcefully attaching socket to the port 8080 - For address reuse 
	if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt))) { 
		perror("setsockopt"); 
		exit(EXIT_FAILURE); 
	} 
	
	address.sin_family = AF_INET; // match the socket() call 
	address.sin_addr.s_addr = INADDR_ANY; // bind to any local address 
	address.sin_port = htons(PORT);   // specify port to listen on 
	// Forcefully attaching socket to the port 8080 
	
	// Binding the socket to the client socket
	if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) { 
		perror("bind failed"); 
		exit(EXIT_FAILURE); 
	} 
	
	// Start listening on the socket
	if (listen(server_fd, 3) < 0) { 
		perror("listen"); 
		exit(EXIT_FAILURE); 
	}
	
	// Storing the client socket once we connect to the client
	if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen)) < 0) { 
		perror("accept"); 
		exit(EXIT_FAILURE); 
	} 
	
	// Opening the file for Q&A Process
	FILE *file = fopen("answers.txt","r");
	if(file == NULL){
		printf("Error in opening a file!\n");
		return -1;
	}
	
	printf("\n");
	while (1) { 
	
		memset(buffer, 0, MAX); // Clearing the buffer
		valread = read(new_socket, buffer, MAX); // Read the question from client
		
		if(!strcmp(buffer,exit_msg)){
			printf("Connection to client closed successfully.\n");
			close(new_socket);
			break;
		}
		
		printf("Question From Client: %s", buffer); 
		memset(answer, 0, MAX); // Clearing the buffer
		fgets(answer, MAX, file); // Reading the answer from the file
		send(new_socket, answer, strlen(answer),0); // Send the answer
		printf("Replied to client successfully\n\n"); 
		
		memset(answer, 0, MAX); // Clearing the buffer
	} 
	
	printf("Exiting from Server now.\n");
	// Closing the file
	fclose(file);
	return 0; 
} 
