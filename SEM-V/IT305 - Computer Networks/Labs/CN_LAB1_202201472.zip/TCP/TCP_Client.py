from socket import *

server_name = "localhost"
server_port = 8000

client_socket = socket(AF_INET, SOCK_STREAM)
client_socket.connect((server_name, server_port))

message = "Hello, I am Rahul Prajapati!"
client_socket.send(message.encode())

server_message = client_socket.recv(1024)
print(server_message.decode())

client_socket.close()