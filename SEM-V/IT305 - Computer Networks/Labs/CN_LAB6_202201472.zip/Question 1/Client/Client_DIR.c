#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define PORT 8000
#define MAX_BUFFER_SIZE 10000

void receiveAndPrintList(int socket) {
    char buffer[MAX_BUFFER_SIZE];
    int bytesRead;

    // Receive and print the list of files from the server
    while (1) {
        bytesRead = recv(socket, buffer, sizeof(buffer), 0);
        if (bytesRead <= 0) {
            break;
        }
        buffer[bytesRead] = '\0';
        printf("%s", buffer);
    }
}

int main() {
    int clientSocket;
    struct sockaddr_in serverAddr;
    char buffer[MAX_BUFFER_SIZE];

    // Create socket
    clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket < 0) {
        perror("socket");
        exit(1);
    }
    // Connect to server
    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(PORT);
    serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(clientSocket, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("connect error");
        exit(1);
    }
    // Request the directory path from the user
    printf("Enter the directory path to list files: ");
    fgets(buffer, sizeof(buffer), stdin);
    buffer[strcspn(buffer, "\n")] = '\0'; // Remove newline character
    send(clientSocket, buffer, strlen(buffer), 0); // Send the directory path to the server
    receiveAndPrintList(clientSocket); // Receive and print the list of files from the server
    close(clientSocket); // Close socket
    return 0;
}
