#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <dirent.h>
#include <pthread.h>

#define PORT 8000
#define MAX_BUFFER_SIZE 10000

// Function to list files in a directory
void listFiles(int clientSocket, const char *path) {
    DIR *dir;
    struct dirent *entry;
    char buffer[MAX_BUFFER_SIZE];

    dir = opendir(path);
    if (dir == NULL) {
        perror("opendir");
        return;
    }
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_REG) {
            snprintf(buffer, sizeof(buffer), "%s\n", entry->d_name);
            send(clientSocket, buffer, strlen(buffer), 0);
        }
    }
    closedir(dir);
}

// Function to handle each client
void *clientHandler(void *arg) {
    int clientSocket = *((int *)arg);
    char buffer[MAX_BUFFER_SIZE];

    // Receive the directory path from the client
    int bytesRead = recv(clientSocket, buffer, sizeof(buffer), 0);
    if (bytesRead <= 0) {
        perror("recv");
        close(clientSocket);
        pthread_exit(NULL);
    }
    buffer[bytesRead] = '\0';

    printf("Client requested listing for directory: %s\n", buffer);

    // List files in the requested directory
    listFiles(clientSocket, buffer);

    // Close the client socket
    close(clientSocket);
    pthread_exit(NULL);
}

int main() {
    int serverSocket, clientSocket;
    struct sockaddr_in serverAddr, clientAddr;
    socklen_t clientAddrLen = sizeof(clientAddr);
    pthread_t tid;

    // Create socket
    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket < 0) {
        perror("socket");
        exit(1);
    }

    // Bind socket
    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(PORT);
    serverAddr.sin_addr.s_addr = INADDR_ANY;

    if (bind(serverSocket, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("bind");
        exit(1);
    }

    // Listen for incoming connections
    if (listen(serverSocket, 5) < 0) {
        perror("listen");
        exit(1);
    }

    printf("Server listening on port %d...\n", PORT);

    while (1) {
        // Accept incoming connection
        clientSocket = accept(serverSocket, (struct sockaddr *)&clientAddr, &clientAddrLen);
        if (clientSocket < 0) {
            perror("accept");
            continue;
        }

        printf("Accepted connection from %s:%d\n", inet_ntoa(clientAddr.sin_addr), ntohs(clientAddr.sin_port));

        // Create a new thread to handle the client
        if (pthread_create(&tid, NULL, clientHandler, &clientSocket) != 0) {
            perror("pthread_create");
            close(clientSocket);
        }

        // Detach the thread to clean up resources automatically
        pthread_detach(tid);
    }

    close(serverSocket);

    return 0;
}
