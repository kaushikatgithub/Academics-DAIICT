#include <unistd.h>
#include <sys/stat.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define FNAME file1
#define PORT 8010
#define BUFSIZE 10000
#define LISTENQ 10

void *handle_put_request(void *arg)
{

    int client_socket = *((int *)arg);
    char buffer[BUFSIZE];
    FILE *received_file;
    int n;

    // Receive the file name
    char filename[BUFSIZE];
    recv(client_socket, filename, sizeof(filename), 0);
    printf("Received file name: %s\n", filename);

    // Create a new file for writing
    received_file = fopen(filename, "wb");
    if (received_file == NULL)
    {
        perror("File open error");
        exit(1);
    }

    // Receive and write the file data
    while ((n = recv(client_socket, buffer, sizeof(buffer), 0)) > 0)
    {
        fwrite(buffer, 1, n, received_file);
    }

    fclose(received_file);
    printf("File received and saved\n");
    close(client_socket);
    pthread_exit(NULL);
}

int main(int argc, char **argv)
{
    int listenfd, connfd, fd, pid, n, size;
    struct sockaddr_in servaddr;
    char buf[BUFSIZE], fname[50];
    struct stat stat_buf;

    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(PORT);

    bind(listenfd, (struct sockaddr *)&servaddr, sizeof(servaddr));
    listen(listenfd, LISTENQ);
    printf("Ready for connect with client\n");

    for (;;)
    {
        connfd = accept(listenfd, (struct sockaddr *)NULL, NULL);
        printf("connected with client\n");
        pid_t pid = fork();
        
        if (pid == 0)
        {                    // Child process
            close(listenfd); // Close server socket in child
            pthread_t tid;   // Create a thread to handle the PUT request
            if (pthread_create(&tid, NULL, handle_put_request, &connfd) != 0)
            {
                perror("Thread creation error");
                exit(1);
            }
            pthread_join(tid, NULL); // Wait for the thread to finish
            exit(0);
        }
        else if (pid < 0)
        {
            perror("Fork error");
            exit(1);
        }
        else
        {
            close(connfd);
        }
    }
}
