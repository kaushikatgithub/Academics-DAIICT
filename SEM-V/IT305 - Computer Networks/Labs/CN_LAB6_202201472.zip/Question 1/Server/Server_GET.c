#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>

#define PORT 8010
#define BUFSIZE 10000
#define LISTENQ 10
void handle_client(int connfd) {
    char buffer[BUFSIZE], fname[BUFSIZE];
    FILE *fp;
    int n;
    recv(connfd, fname, sizeof(fname), 0);
    printf("Requested file: %s\n", fname);

    fp = fopen(fname, "rb");
    if (fp == NULL) {
        perror("File not found");
        exit(1);
    }
    while ((n = fread(buffer, 1, sizeof(buffer), fp)) > 0) { send(connfd, buffer, n, 0); }
    printf("File sent succesfully\n");
    fclose(fp); close(connfd);
}

int main(int argc, char **argv) {
    
    int listenfd, connfd, fd, pid, n, size;
    struct sockaddr_in servaddr;
    char buf[BUFSIZE], fname[50];
    struct stat stat_buf;

    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(PORT);

    bind(listenfd, (struct sockaddr *)&servaddr, sizeof(servaddr));
    listen(listenfd, LISTENQ);
    printf("Ready for connect with client\n");

    for (;;) {
        connfd = accept(listenfd, (struct sockaddr *)NULL, NULL);
        printf("Connected to client\n");
        pid_t pid = fork();
        if (pid == 0) { // Child process
            close(listenfd); // Close server socket in child
            handle_client(connfd);
            exit(0);
        } else if (pid < 0) {
            perror("Fork error"); 
            exit(1);
        } else { close(connfd); }
    }
    return 0;
}
