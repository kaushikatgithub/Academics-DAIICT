#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <time.h>
#define PORT 12345
#define MAX_FILE_SIZE 1024

struct param
{
    int Connection_fd;
    struct sockaddr_storage Client_Adress;
    int ii;
};

void *handle_client(void *arg)
{

    struct param *ptr = arg;
    int connfd = ptr->Connection_fd;
    int client_socket = *((int *)arg);
    char client_ip[INET_ADDRSTRLEN];
    struct sockaddr_in client_addr;
    socklen_t client_addr_len = sizeof(client_addr);
    inet_ntop(AF_INET, &(client_addr.sin_addr), client_ip, INET_ADDRSTRLEN);

    // printf("Connected to client %s:%d\n", client_ip, ntohs(client_addr.sin_port));
    time_t rawtime1;
    struct tm *info1;
    time(&rawtime1);
    info1 = localtime(&rawtime1);
    printf("File Sharing Started at: %s", asctime(info1));

    char filename[256];
    ssize_t bytes_received = recv(client_socket, filename, sizeof(filename), 0);

    time_t rawtime2;
    struct tm *info2;
    time(&rawtime2);
    info2 = localtime(&rawtime2);
    printf("File Sharing Ended at: %s", asctime(info2));

    if (bytes_received <= 0)
    {
        perror("Filename receive error");
        close(client_socket);
        time_t rawtime1;
        struct tm *info1;
        time(&rawtime1);
        info1 = localtime(&rawtime1);
        printf("Client%d disconnected at: %s", ptr->ii, asctime(info1));
        return NULL;
    }

    filename[bytes_received] = '\0';
    printf("\nReceived filename from client %d : %s\n", ptr->ii, filename);

    FILE *file = fopen(filename, "rb");
    if (file == NULL)
    {
        perror("File open error");
        close(client_socket);
        return NULL;
    }

    char file_data[MAX_FILE_SIZE];
    size_t file_size = fread(file_data, 1, MAX_FILE_SIZE, file);
    send(client_socket, file_data, file_size, 0);

    fclose(file);
    close(client_socket);

    time_t rawtime3;
    struct tm *info3;
    time(&rawtime3);
    info3 = localtime(&rawtime3);
    printf("Client%d disconnected at: %s", ptr->ii, asctime(info3));

    // printf("Connection closed for client%d %s:%d\n",ptr->ii, client_ip, ntohs(client_addr.sin_port));
    return NULL;
}

int main()
{
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_len = sizeof(client_addr);

    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) { perror("Socket creation error"); exit(1); }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Binding error"); exit(1);
    }

    if (listen(server_socket, 1) < 0) { perror("Listening error"); exit(1); }

    int kk = 1;
    printf("Server listening on port %d...\n", PORT);

    while (1)
    {
        struct param *NewClient = (struct param *)malloc(sizeof(struct param));
        printf("Waiting for client to connect:\n\n");

        NewClient->Connection_fd = accept(server_socket, (struct sockaddr *)&client_addr, &client_addr_len);

        time_t rawtime;
        struct tm *info;
        time(&rawtime);
        info = localtime(&rawtime);

        NewClient->ii = kk;

        printf("\n***Connected To Client %d***\n", NewClient->ii);
        printf("Client%d connected at: %s", NewClient->ii, asctime(info));

        // getnameinfo((struct sockaddr *)(&(NewClient->Client_Adress)), Client_len, Client_Name, 200, Client_port, 200, 0);
        pthread_t thread;

        // pthread_create(&thread, NULL, read_file, (void *)NewClient);
        pthread_create(&thread, NULL, handle_client, (void *)NewClient);
        kk++;
    }

    close(server_socket);
    return 0;
}
