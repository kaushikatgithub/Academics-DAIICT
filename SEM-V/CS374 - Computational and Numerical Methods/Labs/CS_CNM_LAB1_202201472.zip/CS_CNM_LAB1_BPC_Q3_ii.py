import numpy as np
import math as mt
import matplotlib.pyplot as plt

def gaussian(x):
    return np.exp(-1 * x * x)

def lorentz(x):
    return 1-x*x

low, high = 0, 10
step = 0.0001
x = np.arange(low, high, step)
g = gaussian(x)
l = lorentz(x)
diff = abs(g-l)

plt.figure(1)
plt.plot(x, g, label=f"G(X) = exp(-x^2)")
plt.plot(x, l, label=f"L(X) = 1-x^2")
plt.xlabel("X")
plt.ylabel("F(X)")
plt.xlim(0, 10)
plt.ylim(-0.25, 1)
plt.title(f"Plot of gaussian v/s lorentz functions")
plt.legend()
plt.grid(True)

plt.figure(2)
plt.plot(x, diff, label=f"F(X) = |G(x)-L(x)|")
plt.xlabel("X")
plt.ylabel("F(X)")
plt.title(f"Plot of (gaussian - lorentz) function")
plt.legend()
plt.grid(True)
plt.show()

