import numpy as np
import math as mt
import matplotlib.pyplot as plt

def plot_function(function_list, low, high, y_labels = ["F(X)"]):

    step = 0.0001
    if not hasattr(plot_function, "static_var"):
        plot_function.fig_cnt = 0

    n = len(function_list)
    x = np.arange(low, high, step)
    y_list = [] 
    for function in function_list:
        y_list.append(function(x))

    for i in range(n):
        plt.figure(plot_function.fig_cnt)
        plt.plot(x, y_list[i], label=f"F(X) = {y_labels[i]}")
        plt.xlabel("X")
        plt.ylabel("F(X)")
        plt.title(f"Plot of function F(x)")
        plt.legend()
        plt.grid(True)
    plt.show()
    
    plot_function.fig_cnt += 1
# End
    
k_values = [-4, -2, -1, 1, 2, 4]
for k in k_values:
    plot_function(function_list=[lambda x: np.sin(k*x)], low=-np.pi, high=np.pi, y_labels=[f"sin({k}x)"])

plot_function(function_list=[lambda x: np.sin(x), lambda x: np.sin(x) ** 2], low=-np.pi, high=np.pi, y_labels=[f"sin(x)", f"sin(x) * sin(x)"])


