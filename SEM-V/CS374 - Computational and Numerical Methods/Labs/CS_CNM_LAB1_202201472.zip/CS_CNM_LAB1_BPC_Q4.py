import numpy as np
import math as mt
import matplotlib.pyplot as plt

def plot_function(function_list, low, high, step = 0.01, y_labels = ["F(X)"]):

    if not hasattr(plot_function, "static_var"):
        plot_function.fig_cnt = 0

    n = len(function_list)
    x = np.arange(low, high, step)
    y_list = [] 
    for function in function_list:
        y_list.append(function(x))

    for i in range(n):
        plt.figure(plot_function.fig_cnt)
        plt.plot(x, y_list[i], label=f"F(X) = {y_labels[i]}")
        plt.xlabel("X")
        plt.ylabel("F(X)")
        plt.title(f"Plot of function F(X) = xln(x)")
        plt.legend()
        plt.grid(True)
    plt.show()

    plot_function.fig_cnt += 1
# End

plot_function(function_list=[lambda x: x*np.log(x)], low=0.01, high=2, y_labels=["xln(x), 0<x<2"])
plot_function(function_list=[lambda x: x*np.log(x)], low=0.01, high=1000, y_labels=["xln(x), large x(=1000)"])


