import numpy as np
import math as mt
import matplotlib.pyplot as plt

def plot_function(function_list, low, high, step = 0.0001, y_labels = ["F(X)"]):

    if not hasattr(plot_function, "static_var"):
        plot_function.fig_cnt = 0

    n = len(function_list)
    x = np.arange(low, high, step)
    y_list = [] 
    for function in function_list:
        y_list.append(function(x))

    for i in range(n):
        plt.figure(plot_function.fig_cnt)
        plt.plot(x, y_list[i], label=f"F(X) = {y_labels[i]}")
        plt.xlabel("X")
        plt.ylabel("F(X)")
        plt.title(f"Plot of function F(X)")
        plt.legend()
        plt.grid(True)
    plt.show()

    plot_function.fig_cnt += 1
# End

plot_function(function_list=[lambda x: np.exp(x)], low=-5, high=5, y_labels=["exp(x)"])
plot_function(function_list=[lambda x: x], low=-5, high=5, y_labels=["x"])
plot_function(function_list=[lambda x: np.log(x)], low=0.1, high=5, y_labels=["ln(x)"])
plot_function(function_list=[lambda x: np.exp(x), lambda x: np.exp(-x)], low=-3, high=3, y_labels=["exp(x)", "exp(-x)"])

