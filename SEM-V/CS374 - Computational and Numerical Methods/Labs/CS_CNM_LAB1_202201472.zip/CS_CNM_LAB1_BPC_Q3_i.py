import numpy as np
import math as mt
import matplotlib.pyplot as plt

def plot_function(function_list, low, high, params, y_labels = ["F(X)"]):

    step = 0.0001
    if not hasattr(plot_function, "static_var"):
        plot_function.fig_cnt = 0

    n = len(function_list)
    x = np.arange(low, high, step)
    y_list = [] 
    for function in function_list:
        y_list.append(function(x))

    for i in range(n):
        plt.figure(plot_function.fig_cnt)
        plt.plot(x, y_list[i], label=f"F(X) = {y_labels[i]}")
        plt.xlabel("X")
        plt.ylabel("F(X)")
        plt.title(f"Plot of function F(X). yo={params[0]}, a={params[1]}, μ={params[2]}")
        plt.legend()
        plt.grid(True)
    plt.show()

    plot_function.fig_cnt += 1
# End
    
yo_values = [2, 1, 3, 1, 2]
mu_values = [-2, -1, 0, 1, 2]
a_values = [0.1, 0.3, 0.5, 1, 1.5]
fun_label = "Yo*exp(-a(x-μ)^2)"
for i in range(5):
    plot_function(function_list=[lambda x: yo_values[i] * np.exp(-a_values[i] * ((x-mu_values[i]) ** 2))], low=-10, high=10, params = [yo_values[i], a_values[i], mu_values[i]], y_labels=[fun_label])


