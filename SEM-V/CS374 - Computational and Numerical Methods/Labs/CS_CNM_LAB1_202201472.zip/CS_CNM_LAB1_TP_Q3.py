import numpy as np
import math as mt
import matplotlib.pyplot as plt

def y_aprx_divergent(n, x):
    if n == 0:
        return 0.0
    return (((-1) ** (n-1)) * ((x-1) ** n)) / n

# def y_aprx_convergent(n, x):
#     if n == 0:
#         return 0.0
#     return (((-1) ** (n)) * (((1/x)-1) ** n)) / n

low, high = 0, 100
degrees = np.arange(low, high+1, 1)
print(degrees)
x_values = [2, 3, 4]

# Divergent
for x in x_values:

    y_value_aprx = 0.0
    y_value = np.log(x)
    error = [0.0] * (high-low+1)
    
    for deg in degrees:
        y_value_aprx += y_aprx_divergent(deg, x)
        error[deg] = float(abs(y_value - y_value_aprx))

    plt.figure(x)
    plt.plot(degrees, error, label="Error")
    plt.xlabel("Degree")
    plt.ylabel("Error")
    plt.title(f"Error v/s Degree of Polynomial for x={x}")
    plt.legend()
    plt.grid(True)

plt.show()

# # Convergent
# for x in x_values:

#     y_value_aprx = 0.0
#     y_value = np.log(x)
#     error = [0.0] * (high-low+1)
    
#     for deg in degrees:
#         y_value_aprx += y_aprx_convergent(deg, x)
#         error[deg] = float(abs(y_value - y_value_aprx))

#     plt.figure(x)
#     plt.plot(degrees, error, label="Error")
#     plt.xlabel("Degree")
#     plt.ylabel("Error")
#     plt.title(f"Error v/s Degree of Polynomial for x={x}")
#     plt.legend()
#     plt.grid(True)

# plt.show()

