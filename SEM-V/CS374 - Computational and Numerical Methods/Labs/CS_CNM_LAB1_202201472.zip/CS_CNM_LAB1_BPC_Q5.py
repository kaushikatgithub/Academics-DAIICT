import numpy as np
import math as mt
import matplotlib.pyplot as plt

a_values = [0, 15, 30]
low, high = -5, 5
step = 0.01

x = np.arange(low, high, step)

# A
y = lambda x: -a*x + x**3
dy = lambda x: -a + 3*x*x
d2y = lambda x: 6*x

for a in a_values:
   
    plt.figure(figsize=(6, 8), dpi = 100)
    plt.subplot(3, 1, 1)
    plt.suptitle(f"Question A: y = -ax + x^3 with a = {a}")
    plt.plot(x, y(x), label=f"y = -ax + x^3")
    plt.xlabel("X")
    plt.ylabel("F(X)")
    plt.title(f"Plot of Function F(X)")
    plt.legend()
    plt.grid(True)

    plt.subplot(3, 1, 2)
    plt.plot(x, dy(x), label=f"y = -a + 3x^2")
    plt.xlabel("X")
    plt.ylabel("F'(X)")
    plt.title(f"Plot of Function F'(X)")
    plt.legend()
    plt.grid(True)

    plt.subplot(3, 1, 3)
    plt.plot(x, d2y(x), label=f"y = 6x")
    plt.xlabel("X")
    plt.ylabel('F"(X)')
    plt.title(f'Plot of Function F"(X)')
    plt.legend()
    plt.grid(True)

    # plt.subplots_adjust(hspace=0.320, left=0.13, bottom=0.05, right=0.950, top=910)
    plt.show()


# B
y = lambda x: -a*x*x + x**4
dy = lambda x: -2*a*x + 4 * x**3
d2y = lambda x: -2*a + 12 * x**2

for a in a_values:
   
    plt.figure(figsize=(6, 8), dpi = 100)
    plt.subplot(3, 1, 1)
    plt.suptitle(f"Question B: y = -ax^2 + x^4 with a = {a}")
    plt.plot(x, y(x), label=f"y = -ax^2 + x^4")
    plt.xlabel("X")
    plt.ylabel("F(X)")
    plt.title(f"Plot of Function F(X)")
    plt.legend()
    plt.grid(True)

    plt.subplot(3, 1, 2)
    plt.plot(x, dy(x), label=f"y = -2ax + 4x^3")
    plt.xlabel("X")
    plt.ylabel("F'(X)")
    plt.title(f"Plot of Function F'(X)")
    plt.legend()
    plt.grid(True)

    plt.subplot(3, 1, 3)
    plt.plot(x, d2y(x), label=f"y = -2a + 12x^2")
    plt.xlabel("X")
    plt.ylabel('F"(X)')
    plt.title(f'Plot of Function F"(X)')
    plt.legend()
    plt.grid(True)

    # plt.subplots_adjust(hspace=0.4)
    # plt.subplots_adjust(wspace=0.2)
    plt.show()


