import numpy as np
import math as mt
import matplotlib.pyplot as plt

y = lambda x: np.log(x)
def taylor(n, x):
    if n == 0:
        return 0
    return ((-1) ** (n-1)) * ((x-1) ** n) / n

y_aprx, deg = 0.0, 0
while abs(y(2) - y_aprx) >= 0.01:
    deg += 1
    y_aprx += taylor(deg, 2)
    
print(deg)




