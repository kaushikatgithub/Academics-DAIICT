"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-1 Question 3
    
"""
# Import required libraries
import matplotlib.pyplot as plt
import math as mt
from math import erf as math_erf # only supports scalars
import numpy as np
erf = np.vectorize(math_erf) 

x = np.arange(-1, 1, 0.01)
F = (np.sqrt(np.pi)/2)*(1+erf(x)) # Actual function value
E = 1e-7  # Given maximum error

# Integration value by taylor series expansion up to n terms(without remainder term)
def f(x, n):
    res = mt.sqrt(mt.pi)/2
    for i in range(0, n):
        res += (((-1)**i)*(x**(2*i+1)))/((2*i+1)*mt.factorial(i)) # General term
    return res

# Remainder term as a function of n with value Xi
def Rn(n, x, Xi):
    return np.abs((((x)**(2*n+3))*np.exp(Xi))/((2*n+3)*mt.factorial(n+1)))

# Calculating Error and n
Error, n = 0, 0
while True:
    Error = Rn(n, 1, 1)
    if(Error <= E):
        break
    n += 1
# end

print("N : " + str(n))
print("Error : " + str(Error))

# Approximated function value if n terms are taken
Aprx_f = f(x, n)  

# Plot of Error Term Rn w.r.t n
plt.plot(x, Rn(n, x, 1), label = 'Rn(x)')
plt.plot(x, abs(F-Aprx_f), label = '|F - aprxF|')
plt.xlabel('x')
plt.ylabel('Error')
plt.title('Plot of Error')
plt.grid(True)
plt.legend()
plt.show()
# plt.savefig('ICP_LAB1_Q3.png', orientation='portrait')
