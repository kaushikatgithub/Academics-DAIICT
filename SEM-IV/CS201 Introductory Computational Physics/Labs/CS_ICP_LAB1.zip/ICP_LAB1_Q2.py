"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-1 Question 2
    
"""
# Import required libraries
import matplotlib.pyplot as plt
import numpy as np
import math as mt

x = np.arange(0, 1, 0.01)
I = 1.3179 # Actual integration value
E = 1e-16  # Given maximum error

# Integration value by taylor series expansion up to n terms(without remainder term)
def f(x, n):
    res = 0
    for i in range(1, n+1):
        res += (x**i)/(i*mt.factorial(i)) # General term
    return res

# Remainder term as a function of n with value Xi
def Rn(n, Xi):
    return np.abs(np.exp(Xi)/((n+1)*mt.factorial(n+1)))

# Calculating Error and n
Error, n = 0, 0
while True:
    Error = Rn(n, 1)
    if(Error <= E):
        break
    n += 1
# end

print("The value of n is " + str(n))
print("Error is " + str(Error) + " if the taylor series is truncated to " + str(n) + " terms.")

# Approximated integration value if n terms are taken
Aprx_I = f(1, n)  
print("Actual intergration value : " + str(I))
print("Approximate intergration value : " + str(Aprx_I))

# Plot of error term Rn w.r.t Xi
Xi = np.arange(0, 1, 0.001)
plt.plot(Xi, Rn(n, Xi))
plt.xlabel('Xi')
plt.ylabel('Rn(Xi)')
plt.title('Plot of Error Term Rn(Xi)')
plt.grid(True)
plt.show()
# plt.savefig('ICP_LAB1_Q2.png', orientation='portrait')