"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-1 Question 4
    
"""

# Import required libraries
import matplotlib.pyplot as plt
from scipy.special import sici, exp1
import math as mt
from math import erf as math_erf # only supports scalars
import numpy as np
erf = np.vectorize(math_erf) 

x = np.arange(-1, 1, 0.01)
F = sici(x)[0] / x # Actual function value
E = 1e-7  # Given maximum error

# Integration value by taylor series expansion up to n terms(without remainder term)
def f(x, n):
    res = np.zeros_like(x) 
    for i in range(0, n):
        res += (((-1)**i)*(x**(2*i)))/((2*i+1)*mt.factorial(2*i+1)) # General term
    return res

# Remainder term as a function of n with value Xi
def Rn(n, x, Xi):
    return np.abs((((x)**(2*n))*mt.cos(Xi))/((2*n+1)*mt.factorial(2*n+1)))

# Calculating Error and n
Error, n = 0, 0
while True:
    Error = Rn(n, 1, 1)
    if(Error <= E):
        break
    n += 1
# end

print("N : " + str(n))
print("Error : " + str(Error))

# Approximated function value if n terms are taken
Aprx_f = f(x, n)  

plt.plot(x, Rn(n, x, 1), label = 'Rn(x)') # Plot of Error Term Rn w.r.t n
plt.plot(x, abs(F-Aprx_f), label = '|F - aprxF|')
plt.xlabel('x')
plt.ylabel('Error')
plt.title('Plot of Error')
plt.grid(True)
plt.legend()
plt.show()
# plt.savefig('ICP_LAB1_Q4.jpeg', orientation='portrait')
