"""
    Name: Kaushik Prajapati
    SID : 202201472
    CT Lab-1 Question 1
    
"""

# Import required libraries
import matplotlib.pyplot as plt
import numpy as np
import math as mt

# Figure dimension ratio
plt.figure(figsize=(7, 8), dpi = 100)

# X input range
x = np.arange(0, 1, 0.01)

# Given function
def f(x):
    return (1/(1+x)**2)

# Taylor series evaluation around point a with n terms
def taylorEvaluation(x, a, n):

    # Calculating taylor series around point a with n terms
    res = 0.00
    for i in range(n):
       res += ((-1)**i)*(i+1)*((x-a)**i)/((1+a)**(i+2))
    return res

# Tuples (n, a)
values = [(3, 0), (3, 0.5), (3, 0.8), (5, 0), (5, 0.5), (5, 0.8)]

# Plotting all the figures
i = 1
for n, a in values:

    plt.subplot(3, 2, i)
    plt.plot(x, f(x), label = 'f(x)')
    plt.plot(x, taylorEvaluation(x, a, n), label = 'aprx_f(x)')

    plt.title('Approx f(x) with n='+str(n)+', a='+str(a), fontsize=10)
    plt.xlabel('x-axis', fontsize = 10)
    plt.ylabel('y-axis', fontsize = 10)
    plt.grid(True)
    plt.xlim([0, 1])
    plt.ylim([0, 2.5])
    plt.legend(fontsize = 7)
    i += 1


plt.subplots_adjust(hspace=1)
plt.subplots_adjust(wspace=0.2)
# plt.savefig('ICP_LAB1_Q1_Revised.png', orientation='portrait')
plt.show()

"""
    -> Here we are just plotting n (3 or 5) terms of taylor series without using remainder term
       so these excluded terms results into error
    -> Error depends on how many terms we are considering in taylor series expansion.
    -> The error is also dependent on a value around which we are expanding taylor series for the
       given function
"""