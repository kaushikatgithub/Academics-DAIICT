"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-4 Question 1(ii)
    Euler-Cromer Method
    
"""

import numpy as np
import math as mt
import matplotlib.pyplot as plt

def plotGraphs(A, B, N, curve):

    a = A
    b = B
    n = N
    h = (b-a)/n
    t = np.arange(a, b, h)

    alpha = curve[0]
    X = [curve[1]] * n
    Y = [curve[2]] * n
    Vx = [curve[3]] * n 
    Vy = [curve[4]] * n


    for i in range(1, n):
        Vx[i] = Vx[i-1] - (((h * alpha) * X[i-1]) / ((mt.sqrt(X[i-1]*X[i-1] + Y[i-1]*Y[i-1]))**3))
        Vy[i] = Vy[i-1] - (((h * alpha) * Y[i-1]) / ((mt.sqrt(X[i-1]*X[i-1] + Y[i-1]*Y[i-1]))**3))
        X[i] =  h * Vx[i] + X[i-1]
        Y[i] =  h * Vy[i] + Y[i-1]
   

    plt.figure(1)
    plt.plot(X, Y, label = "XY Plan")
    plt.xlabel("X")
    plt.ylabel("Y")
    plt.title(f"{curve[5]}")
    plt.legend()
    plt.grid(True)

    plt.figure(2)
    plt.plot(t, Vx, label = "Vx(t)")
    plt.plot(t, Vy, label = "Vy(t)")
    plt.xlabel("time(s)")
    plt.ylabel("V(m/s)")
    plt.title("Velocity V(m/s)")
    plt.legend()
    plt.grid(True)

    plt.show()
        
# Ellipse, Circle, Parabola values: alpha, Xo, Yo, Vxo, Vyo
curve_tuples  = [
                 (1, 1, 0, 0.3, 1, "Ellipse"),  
                 (1, 1, 0, 0, 1, "Circle"),    
                 (1, 1, 0, 0.96, 1, "Parabola") 
                ]

# XY_curve_limits = [[(-0.3, 1.2), (-0.5, 0.65)], [(-0.3, 1.2), (-0.6, 0.6)], [(-3.5, 1.2), (-0.5, 3.5)]]

a = 0
b = 100
n = 100000

for i in range(3):
    plotGraphs(a, b, n, curve_tuples[i])



############ USE FOR ORIGINAL CUEVES ##############

# # Ellipse, Circle, Parabola values: alpha, Xo, Yo, Vxo, Vyo
# curve_tuples  = [(1, 1, 0, 0.3, 1), (1, 1, 0, 0, 1), (0.55, 1, 0, 0, 1)]
# legend_tuple = ["Ellipse", "Circle", "Parabola"]
# XY_curve_limits = [[(-0.3, 1.2), (-0.5, 0.65)], [(-0.3, 1.2), (-0.6, 0.6)], [(-3.5, 1.2), (-0.5, 3.5)]]
    


