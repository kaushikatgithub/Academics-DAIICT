"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-4 Question 2
    RK4 Method
    
"""

import numpy as np
import math as mt
import matplotlib.pyplot as plt

# Fy(t, Vy) funtion
def Fy(alpha, X, Y):
    r = mt.sqrt(X**2 + Y**2)
    return (alpha*Y)/(r**3)

# Fx(t, Vx) funtion
def Fx(alpha, X, Y):
    r = mt.sqrt(X**2 + Y**2)
    return (alpha*X)/(r**3)

def RK4_Method_Plots(A, B, N, Alpha, Xo, Yo, Vxo, Vyo, curve):

    a = A
    b = B
    n = N
    h = (b-a)/n
    alpha = Alpha

    t = np.arange(a, b, h)
    X = [Xo] * n
    Y = [Yo] * n
    Vx = [Vxo] * n 
    Vy = [Vyo] * n
   
    for i in range(1, n):
       
        # Ki for position X
        K1 = Vx[i-1]
        K2 = Vx[i-1] + h*K1/2
        K3 = Vx[i-1] + h*K2/2
        K4 = Vx[i-1] + h*K3
        X[i] = X[i-1] + h*(K1 + 2*K2 + 2*K3 + K4)/6

        # Ki for position Y
        K1 = Vy[i-1]
        K2 = Vy[i-1] + h*K1/2
        K3 = Vy[i-1] + h*K2/2
        K4 = Vy[i-1] + h*K3
        Y[i] = Y[i-1] + h*(K1 + 2*K2 + 2*K3 + K4)/6
        
        # Ki for velocity Vx
        K1 = Fx(alpha, X[i], Y[i])
        K2 = Fx(alpha, X[i] + h*K1/2, Y[i] + h*K1/2)
        K3 = Fx(alpha, X[i] + h*K2/2, Y[i] + h*K2/2)
        K4 = Fx(alpha, X[i] + h*K3, Y[i] + h*K3)
        Vx[i] = Vx[i-1] + h*(K1 + 2*K2 + 2*K3 + K4)/6

        # Ki for velocity Vy
        K1 = Fy(alpha, X[i], Y[i])
        K2 = Fy(alpha, X[i] + h*K1/2, Y[i] + h*K1/2)
        K3 = Fy(alpha, X[i] + h*K2/2, Y[i] + h*K2/2)
        K4 = Fy(alpha, X[i] + h*K3, Y[i] + h*K3)
        Vy[i] = Vy[i-1] + h*(K1 + 2*K2 + 2*K3 + K4)/6
   
    
    plt.figure(1)
    plt.plot(X, Y, label = "XY Plan")
    plt.title(f"{curve}")
    plt.xlabel("X")
    plt.ylabel("Y")
    plt.legend()
    plt.grid(True)

    plt.figure(2)
    plt.plot(t, Vx, label = "Vx(t)")
    plt.plot(t, Vy, label = "Vy(t)")
    plt.xlabel("time(s)")
    plt.ylabel("V(m/s)")
    plt.title("Velocity V(m/s)")
    plt.legend()
    plt.grid(True)
   
    plt.show()


# Pure Circle
# RK4_Method_Plots(A=0, B=100, N=100000, Alpha=-1, Xo=1, Yo=0, Vxo=0, Vyo=1, curve ="Circle")

# Doubly Circle
RK4_Method_Plots(A=0, B=10, N=500, Alpha=-1, Xo=1, Yo=0, Vxo=0, Vyo=1, curve="Circle")

# Parabola
# RK4_Method_Plots(A=0, B=100, N=1000, Alpha=-1, Xo=1, Yo=0, Vxo=0.96, Vyo=1, curve="Parabola") #Final Parabola

# Pure Ellipse
# RK4_Method_Plots(A=0, B=10, N=100000, Alpha=-1, Xo=1, Yo=0, Vxo=0.3, Vyo=1, curve="Ellipse")

# Doubly Ellipse
# RK4_Method_Plots(A=0, B=100, N=1000, Alpha=-1, Xo=1, Yo=0, Vxo=0.3, Vyo=1, curve="Ellipse")



########################################################################################################
    
# RK4_Method_Plots(A=0, B=1000, N=100000, Alpha=-0.008, Xo=1, Yo=0, Vxo=0.95, Vyo=1)
# RK4_Method_Plots(A=0, B=100, N=100000, Alpha=-1, Xo=1, Yo=0, Vxo=0.96, Vyo=1) Final Parabola

# Parabola
# RK4_Method_Plots(A=0, B=100, N=100000, Alpha=-1, Xo=1, Yo=0, Vxo=0.96, Vyo=1) Final Parabola


# Proper Circle
# RK4_Method_Plots(A=0, B=100, N=100000, Alpha=-1, Xo=1, Yo=0, Vxo=0, Vyo=1)
# a = 0
# b = 10
# n = 100000
# h = (b-a)/n
# alpha = -1
# Xo = 1
# Yo = 0
# Vxo = 0.3
# Vyo = 1

# Doubly Circle
# RK4_Method_Plots(A=0, B=100, N=500, Alpha=-1, Xo=1, Yo=0, Vxo=0, Vyo=1)
# a = 0
# b = 100
# n = 500
# h = (b-a)/n
# alpha = -1
# Xo = 1
# Yo = 0
# Vxo = 0.3
# Vyo = 1

# Normal Ellipse
# RK4_Method_Plots(A=0, B=10, N=100000, Alpha=-1, Xo=1, Yo=0, Vxo=0.3, Vyo=1)
# a = 0
# b = 10
# n = 100000
# h = (b-a)/n
# alpha = -1
# Xo = 1
# Yo = 0
# Vxo = 0.3
# Vyo = 1

# Doubly Ellipse
# RK4_Method_Plots(A=0, B=100, N=100000, Alpha=-1, Xo=1, Yo=0, Vxo=0.3, Vyo=1)
# a = 0
# b = 100
# n = 100000
# h = (b-a)/n
# alpha = -1
# Xo = 1
# Yo = 0
# Vxo = 0.3
# Vyo = 1