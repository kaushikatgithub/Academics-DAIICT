"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-4 Question 1(i)
    Euler Method
    
"""

import numpy as np
import math as mt
import matplotlib.pyplot as plt

# Fy(t, Vy) funtion
def Fy(alpha, X, Y):
    r = mt.sqrt(X**2 + Y**2)
    return (alpha*Y)/(r**3)

# Fx(t, Vx) funtion
def Fx(alpha, X, Y):
    r = mt.sqrt(X**2 + Y**2)
    return (alpha*X)/(r**3)

def plotGraphs(A, B, N, curve):

    a = A
    b = B
    n = N
    h = (b-a)/n

    alpha = curve[0]
    alpha2 = -1*curve[0]
    X_E = [curve[1]] * n
    Y_E = [curve[2]] * n
    Vx_E = [curve[3]] * n 
    Vy_E = [curve[4]] * n

    X_EC = [curve[1]] * n
    Y_EC = [curve[2]] * n
    Vx_EC = [curve[3]] * n 
    Vy_EC = [curve[4]] * n

    
    X_RK = [curve[1]] * n
    Y_RK = [curve[2]] * n
    Vx_RK = [curve[3]] * n 
    Vy_RK = [curve[4]] * n


    for i in range(1, n):

        # Euler Chromer
        Vx_EC[i] = Vx_EC[i-1] - (((h * alpha) * X_EC[i-1]) / ((mt.sqrt(X_EC[i-1]*X_EC[i-1] + Y_EC[i-1]*Y_EC[i-1]))**3))
        Vy_EC[i] = Vy_EC[i-1] - (((h * alpha) * Y_EC[i-1]) / ((mt.sqrt(X_EC[i-1]*X_EC[i-1] + Y_EC[i-1]*Y_EC[i-1]))**3))
        X_EC[i] =  h * Vx_EC[i] + X_EC[i-1]
        Y_EC[i] =  h * Vy_EC[i] + Y_EC[i-1]

        # Euler 
        Vx_E[i] = Vx_E[i-1] - (((h * alpha) * X_E[i-1]) / ((mt.sqrt(X_E[i-1]*X_E[i-1] + Y_E[i-1]*Y_E[i-1]))**3))
        Vy_E[i] = Vy_E[i-1] - (((h * alpha) * Y_E[i-1]) / ((mt.sqrt(X_E[i-1]*X_E[i-1] + Y_E[i-1]*Y_E[i-1]))**3))
        X_E[i] =  h * Vx_E[i-1] + X_E[i-1]
        Y_E[i] =  h * Vy_E[i-1] + Y_E[i-1]

        # RK Method
        
        # Ki for position X
        K1 = Vx_RK[i-1]
        K2 = Vx_RK[i-1] + h*K1/2
        K3 = Vx_RK[i-1] + h*K2/2
        K4 = Vx_RK[i-1] + h*K3
        X_RK[i] = X_RK[i-1] + h*(K1 + 2*K2 + 2*K3 + K4)/6

        # Ki for position Y
        K1 = Vy_RK[i-1]
        K2 = Vy_RK[i-1] + h*K1/2
        K3 = Vy_RK[i-1] + h*K2/2
        K4 = Vy_RK[i-1] + h*K3
        Y_RK[i] = Y_RK[i-1] + h*(K1 + 2*K2 + 2*K3 + K4)/6
        
        # Ki for velocity Vx
        K1 = Fx(alpha2, X_RK[i], Y_RK[i])
        K2 = Fx(alpha2, X_RK[i] + h*K1/2, Y_RK[i] + h*K1/2)
        K3 = Fx(alpha2, X_RK[i] + h*K2/2, Y_RK[i] + h*K2/2)
        K4 = Fx(alpha2, X_RK[i] + h*K3, Y_RK[i] + h*K3)
        Vx_RK[i] = Vx_RK[i-1] + h*(K1 + 2*K2 + 2*K3 + K4)/6

        # Ki for velocity Vy
        K1 = Fy(alpha2, X_RK[i], Y_RK[i])
        K2 = Fy(alpha2, X_RK[i] + h*K1/2, Y_RK[i] + h*K1/2)
        K3 = Fy(alpha2, X_RK[i] + h*K2/2, Y_RK[i] + h*K2/2)
        K4 = Fy(alpha2, X_RK[i] + h*K3, Y_RK[i] + h*K3)
        Vy_RK[i] = Vy_RK[i-1] + h*(K1 + 2*K2 + 2*K3 + K4)/6

    plt.figure(1)
    plt.plot(X_E, Y_E, label = "Euler", linewidth = 1, color = "orange")
    plt.plot(X_EC, Y_EC, label = "Euler-Chromer", linewidth = 3, color = "green")
    plt.plot(X_RK, Y_RK, label = "RK Method", linewidth = 1.1, color = "dodgerblue")
    plt.xlabel("X")
    plt.ylabel("Y")
    plt.title(f"{curve[5]}")
    plt.legend()
    plt.grid(True)

    plt.show()
      
    
# Ellipse, Circle, Parabola values: alpha, Xo, Yo, Vxo, Vyo
curve_tuples  = [
                 (1, 1, 0, 0.3, 1, "Ellipse"),  
                 (1, 1, 0, 0, 1, "Circle"),    
                 (1, 1, 0, 0.96, 1, "Parabola") 
                ]
a = 0
b = 100
n = 100000

for i in range(3):
    plotGraphs(a, b, n, curve_tuples[i])