"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-2 Question 1
    
"""
# Import required libraries
import matplotlib.pyplot as plt
import numpy as np
import math as mt

# Integration Limits
a = 0
b = 2*np.pi

# Actual values of integration
I_fx = -(2*(np.pi)**2)/5
I_gx =  2*(np.pi*(np.log(1 +  (4*(np.pi**2))) - 2) + np.arctan(2*np.pi))

# Problem 1.1
def f(x):
  return x*x*mt.sin(10*x)

#  Problem 1.2
def g(x):
  return np.log(1 + x**2)

# Approximated integartion value using Trapizoidal Rule
def Trapizoidal_Aprx(function , n, a, b):
  h = (b-a) / n # Distance between two node points
  result = (function(a) + function(b)) / 2
 
  for i in range(1,n):
    result += function(a+ (i*h))

  return result * h
 
# Approximated integartion value using Simpson Rule
def Simpson_Aprx(function, n, a, b):
  h = (b-a) / n # Distance between two node points
  result = 0

  for i in range(1,n,2):
    result += function(a+(i-1)*h) + 4*function(a+i*h) + function(a+(i+1)*h)

  return (result * h) / 3
 
# Tuple of values of n
values = (10, 20, 200)

print("\nActual value of integration for F(x): " + str(I_fx))
print("Approximations for F(x):")
for i in values:
  print("\nTrapizoidal Aproximation for n = " + str(i) + ": " + str(Trapizoidal_Aprx(f,i,a,b)))
  print("Simpson Approximation for n = " + str(i) + ": " + str(Simpson_Aprx(f,i,a,b)))

print("\nActual value of integration for G(x): " + str(I_gx))
print("Approximations for G(x):")
for i in values:
  print("\nTrapizoidal Aproximation for n = " + str(i) + ": " + str(Trapizoidal_Aprx(g,i,a,b)))
  print("Simpson Approximation for n = " + str(i) + ": " + str(Simpson_Aprx(g,i,a,b)))

