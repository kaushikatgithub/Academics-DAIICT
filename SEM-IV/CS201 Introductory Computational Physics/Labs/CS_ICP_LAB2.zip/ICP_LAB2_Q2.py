"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-2 Question 2
    
"""

# Import required libraries
import matplotlib.pyplot as plt
import numpy as np
import math as mt

# Iinitial values and constants
Lambda = 0.2
No = 1000
N_infinity = 0
h = 1
n = int((No-N_infinity) // h)

t = [i*h for i in range(n)]       # Time list
N_aprx = [0.0 for i in range(n)]  # Approximated N(t) list
N_aprx[0] = No                    # At t=0, N(t=0) = No

# Euler's Method to solve ODE
for i in range (1,n):
  N_aprx[i] = (1- (Lambda * h)) * N_aprx[i-1]
   
# Actual N(t) function
def N(t, No, Lambda):
  return No * np.exp(-Lambda*t)

time = np.linspace(0, 100, 1000)
N_actual = N(time, No, Lambda)

plt.plot(t, N_aprx, label = "Approx N(t)")
plt.plot(time, N_actual, label = "Analytical N(t)")
plt.ylabel('N(t)')
plt.xlabel('time(s)')
plt.title('Radioactivity')
plt.xlim((0, 100))
plt.ylim((-10, 100))
plt.grid(True)
plt.legend()
plt.show()
# plt.savefig('ICP_LAB2_Q2.png', orientation='portrait')
