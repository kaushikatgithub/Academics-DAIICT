"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-2 Question 3
   
"""

# Import required libraries
import matplotlib.pyplot as plt
import numpy as np
import math as mt

# Iinitial values and constants
Bita, m = -1, 5      # Constant Bita and mass(kg)
Xo, Vo = 100, 20   # Initial position(m) and velocity(m/s)
V_infinity = 0      # At t->infinity => V(t) = 0
h = 2
g = 9.8
n = 1000

# Analytical Solution
# Actual V(t) function
def V(t, Vo, Bita):
  return (Vo + (m*g)/Bita)*np.exp(Bita*t/m) - (m*g)/Bita

# Actual X(t) function
def X(t, Xo, Vo, V_actual):
  return Xo + ((Vo*m)/Bita + (g*m**2)/(Bita**2)) * np.exp(Bita*t/m) - (m*g*t)/Bita

time = np.linspace(0, 100, 1000)
V_actual = V(time, Vo, Bita)
X_actual = X(time, Xo, Vo, V_actual) 

#######################################  Question 3.1  #######################################

X_aprx1 = [0.0 for i in range(n)]   # Approximated X(t) list
X_aprx1[0] = Xo                     # At t=0 X(t=0) = Xo
V_aprx1 = [0.0 for i in range(n)]   # Approximated V(t) list
V_aprx1[0] = Vo                     # At t=0, V(t=0) = Vo
t1 = [i*h for i in range(n)]        # Time list

# Euler's Method to solve ODE for V(t) and X(t)
for i in range(1, n):
    V_aprx1[i] = (1 + (Bita * h) / m) * V_aprx1[i - 1] + g*h
    X_aprx1[i] = X_aprx1[i - 1] + h * V_aprx1[i - 1]
    
#######################################  Question 3.2  #######################################

X_aprx2 = [0.0 for i in range(n+1)]  # Approximated X(t) list    
X_aprx2[0] = Xo-h*Vo                 # X(to-h) Value
X_aprx2[1] = Xo                      # At t=0 X(t=0) = Xo
V_aprx2 = [0.0 for i in range(n)]    # Approximated V(t) list (We'll calculate by numerical differentiation)
t2 = [i*h for i in range(n)]         # Time list

# Euler's Method to solve ODE for V(t) and X(t)
for i in range(2, n+1):
    X_aprx2[i] = ((Bita*h-2*m)*X_aprx2[i-1] + m*X_aprx2[i-2] -m*g*(h**2))/(Bita*h-m)

# Calculating V(t) by numerical differentiaton
for i in range(n):
   V_aprx2[i] = (X_aprx2[i+1]-X_aprx2[i])/h
   
# Question 3.1 plots
# Velocity versus time plot
plt.figure(figsize=(6, 10), dpi = 100)
plt.figure(1)
plt.subplot(2, 1, 1)
plt.plot(t1, V_aprx1, label = "Approx V(t)")
plt.plot(time, V_actual, label = "V(t)")
plt.xlabel('time(s)')
plt.ylabel('V(t)')
plt.title('Velocity-Time (First Order ODE)')
plt.xlim((0, 100))
# plt.ylim((0, 100))
plt.legend()
plt.grid(True)

# Position versus time plot
plt.subplot(2, 1, 2)
plt.plot(t1, X_aprx1, label = "Approx X(t)")
plt.plot(time, X_actual, label = "X(t)")
plt.xlabel('time(s)')
plt.ylabel('X(t)')
plt.title('Position-Time (First Order ODE)')
plt.xlim((0, 100))
plt.ylim((0, 6000))
plt.legend()
plt.grid(True)

plt.subplots_adjust(hspace=0.5)
# plt.savefig('ICP_LAB2_Q3(i).png', orientation='portrait')
# Question 3.1 plots ends

# Question 3.2 plots
# Position versus time plot
plt.figure(figsize=(6, 10), dpi = 100)
plt.figure(2)
plt.subplot(2, 1, 1)
plt.plot(t2, X_aprx2[1:], label = "Approx X(t)")
plt.plot(time, X_actual, label = "X(t)")
plt.xlabel('time(s)')
plt.ylabel('X(t)')
plt.title('Position-Time (Second Order ODE)')
plt.xlim((0, 100))
plt.ylim((0, 6000))
plt.legend()
plt.grid(True)

# Velocity versus time plot
plt.subplot(2, 1, 2)
plt.plot(t2, V_aprx2, label = "Approx V(t)")
plt.plot(time, V_actual, label = "V(t)")
plt.xlabel('time(s)')
plt.ylabel('V(t)')
plt.title('Velocity-Time (Numerical Differentiaion)')
plt.xlim((0, 100))
# plt.ylim((0, 100))
plt.legend()
plt.grid(True)
plt.subplots_adjust(hspace=0.5)

plt.show()
# plt.savefig('ICP_LAB2_Q3(ii).png', orientation='portrait')
# Question 3.2 plots ends
