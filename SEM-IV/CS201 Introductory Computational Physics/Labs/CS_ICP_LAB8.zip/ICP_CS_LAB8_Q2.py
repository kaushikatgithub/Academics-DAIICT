"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-7 Question 1(i)
    
"""

import numpy as np
import math as mt
import matplotlib.pyplot as plt

a = 0
b = 10
n = 1000
h = (b-a)/n
t = np.arange(a, b, h)

# Xo = 2

Xo_Values = [-2*np.pi+0.1, -np.pi, -0.01, 0, 0.01, np.pi, 2*np.pi-0.1]
legends = ["-2\u03c0 < Xo < \u03c0", "Xo = -\u03c0","-\u03c0 < Xo < 0", "Xo = 0", "0 < Xo < \u03c0", "Xo = \u03c0", "\u03c0 < Xo < 2\u03c0"]

# Funtions for RK4 method
def F(X):
    return mt.sin(X)
 
def plot_graphs(Xo, leg):

    X_RK = [Xo] * n

    # Loops for Euler and RK4
    for i in range(1, n):

        # RK-4 Method
        K1 = F(X_RK[i-1])
        K2 = F(X_RK[i-1] + 0.5 * h * K1)
        K3 = F(X_RK[i-1] + 0.5 * h * K2)
        K4 = F(X_RK[i-1] + h * K3)
        X_RK[i] = X_RK[i-1] + (h/6) * (K1 + 2 * K2 + 2 * K3 + K4) 

    plt.figure(0, figsize=(7, 6), dpi = 110) # Figure dimension ratio
    plt.plot(t, X_RK, label = f"{leg}")
    plt.xlabel("time(s)")
    plt.ylabel("X(t)")
    plt.title("X(t)")
    plt.legend()
    plt.grid(True)

for i in range(len(Xo_Values)):
    plot_graphs(Xo_Values[i], legends[i])

plt.savefig("ICP_LAB7_Q2.png")
plt.show()