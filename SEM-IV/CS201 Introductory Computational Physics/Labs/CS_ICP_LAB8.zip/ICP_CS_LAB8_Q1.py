"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-7 Question 1(i)
    
"""

import numpy as np
import math as mt
import matplotlib.pyplot as plt

a = 0
b = 400
n = 10000
h = (b-a)/n
t = np.arange(a, b, h)

A = 0.03
B = 3 * (10 ** (-12))
K = A / B

Xo_Values = [3*K/4, K/2, K/64, 0]
titles = ["Xo > K/2", "Xo = K/2", "Xo < K/2", "Xo = 0"]

# Funtions for RK4 method
def F(X):
    return A * X - B * X * X

def F_analytical(Xo):
    global A, B, K, t
    n = len(t)
    X = [Xo] * n
    for i in range(1, n):
        X[i] = (K * Xo) / (Xo + (K - Xo) * (mt.exp(-A * t[i])))
    return X

def plot_graphs(figNo, Xo, title):
        
    X_E = [Xo] * n
    X_RK = [Xo] * n

    # Loops for Euler and RK4
    for i in range(1, n):
        
        # Euler Method
        X_E[i] = X_E[i-1] + h * F(X_E[i-1])

        # RK-4 Method
        K1 = F(X_RK[i-1])
        K2 = F(X_RK[i-1] + 0.5 * h * K1)
        K3 = F(X_RK[i-1] + 0.5 * h * K2)
        K4 = F(X_RK[i-1] + h * K3)
        X_RK[i] = X_RK[i-1] + (h/6) * (K1 + 2 * K2 + 2 * K3 + K4) 

    X_analytical = F_analytical(Xo)
    plt.figure(figNo, figsize=(8, 12), dpi = 110) # Figure dimension ratio
    plt.suptitle(f"Logistic Equation: Dx = ax - bx\u00b2", fontsize = 16)
    plt.subplot(2, 1, 1)
    plt.plot(t, X_E, label = f"{title}", linewidth = 2, color = "orange")
    plt.plot(t, X_analytical, "b--", label = f"{title} Analytical", dashes=(1, 1))
    plt.xlabel("time(s)")
    plt.ylabel("X(t)")
    plt.title("X(t) Using Euler Method")
    plt.legend(fontsize=10)
    plt.grid(True)

    plt.subplot(2, 1, 2)
    plt.plot(t, X_RK, label = f"{title}", linewidth = 2, color = "orange")
    plt.plot(t, X_analytical, "b--", label = f"{title} Analytical", dashes=(1, 1))
    plt.xlabel("time(s)")
    plt.ylabel("X(t)")
    plt.title("X(t) Using RK4 Method")
    plt.legend(fontsize=10)
    plt.grid(True)

    plt.subplots_adjust(hspace=0.35, top=0.9)

for i in range(4):
    plot_graphs(1, Xo_Values[i], titles[i])
    plt.savefig("ICP_LAB8_Q1.png")
plt.show()

