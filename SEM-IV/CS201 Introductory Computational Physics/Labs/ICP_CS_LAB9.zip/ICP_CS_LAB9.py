"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-7 Question 1(i)
    
"""

import numpy as np
import math as mt
import matplotlib.pyplot as plt

a = 0
b = 20
n = 10000
h = (b-a)/n
t = np.arange(a, b, h)

ab_values = [(4, 0.5, -1), (4, 0.5, 1), (4, 0.5, 4), 
             (25/2, 2/5, -2), (25/2, 2/5, 2), (25/2, 2/5, 6),
             (0.5, -2, -3), (0.5, -2, -1), (0.5, -2, 1), 
             (9/2, -2/3, -6), (9/2, -2/3, -2), (9/2, -2/3, 2)
             ]
titles = ["RK4 Method, ab = 2, ab > 1", "RK4 Method, ab = 2, ab > 1", "RK4 Method, ab = 2, ab > 1", 
          "RK4 Method, ab = 5, ab > 1", "RK4 Method, ab = 5, ab > 1", "RK4 Method, ab = 5, ab > 1",
          "RK4 Method, ab = -1, ab < 1", "RK4 Method, ab = -1, ab < 1", "RK4 Method, ab = -1, ab < 1", 
          "RK4 Method, ab = -4, ab < 1", "RK4 Method, ab = -4, ab < 1", "RK4 Method, ab = -4, ab < 1"]

legends = ["Xo=-1, Xo<0", "Xo=1, 0<Xo<2", "Xo=4, Xo>2", 
           "Xo=-2, Xo<0", "Xo=2, 0<Xo<4", "Xo=6, Xo>4",
           "Xo=-3, Xo<-2", "Xo=-1, -2<Xo<0", "Xo=1, Xo>0",
           "Xo=-6, Xo<-4", "Xo=-2, -4<Xo<0", "Xo=2, Xo>0"
           ]

figNos = [0, 0, 1, 2, 2, 3, 4, 4, 5, 6, 6, 7]
plot = [False, True, True, False, True, True, False, True, True, False, True, True]
Nos = [1, 2, 3, 4, 5, 6, 7, 8]
# Funtions for RK4 method
def F(a, b, x):
    return (1 - a*b)*x + a*b*b*x*x*0.5

def plot_graphs(figNo, a, b, Xo, legend_i, title):
        
    X_RK = [Xo] * n

    # Loops for Euler and RK4
    for i in range(1, n):
        
        # RK-4 Method
        K1 = F(a, b, X_RK[i-1])
        K2 = F(a, b, X_RK[i-1] + 0.5 * h * K1)
        K3 = F(a, b, X_RK[i-1] + 0.5 * h * K2)
        K4 = F(a, b, X_RK[i-1] + h * K3)
        X_RK[i] = X_RK[i-1] + (h/6) * (K1 + 2 * K2 + 2 * K3 + K4) 

    plt.figure(figNo) # Figure dimension ratio
    plt.plot(t, X_RK, label = f"{legend_i}", linewidth = 2)
    plt.xlabel("time(s)")
    plt.ylabel("X(t)")
    plt.title(f"{title}")
    plt.legend(fontsize=10)
    plt.grid(True)

idx = 0
for i in range(len(figNos)):
    plot_graphs(figNos[i], ab_values[i][0], ab_values[i][1], ab_values[i][2], legends[i], titles[i])
    if plot[i]:
        plt.savefig(f"ICP_LAB9_Q1_{Nos[idx]}.png")
        idx += 1
plt.show()

