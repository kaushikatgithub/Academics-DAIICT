"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-5 Question 2
    
"""

import numpy as np
import math as mt
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp

# My Values
a = 0
b = 100
n = 1000
h = (b-a)/n
t = np.arange(a, b, h)

Xo = 1
Yo = 0
Zo = 0

def ODEs(t, vars):
    x, y, z = vars
    dxdt = (-0.04)*x + 10000*y*z
    dydt = 0.04*x - 10000*y*z - (3000000)*(y**2)
    dzdt = (3000000)*(y**2)
    return [dxdt, dydt, dzdt]

initial_conditions = [Xo, Yo, Zo]
t_span = (a, b) 
sol = solve_ivp(ODEs, t_span, initial_conditions)
t1 = sol.t
X_solution = sol.y[0]
Y_solution = sol.y[1]
Z_solution = sol.y[2]

   
plt.figure(1)
# plt.plot(t, X_E, label="X_E")
# plt.plot(t, X_RK, label="X_RK")
plt.plot(t1, X_solution, label='x(t)', linewidth = 3)
plt.xlabel("time(s)")
plt.ylabel("X")
plt.title("X vs time")
plt.legend()
plt.grid(True)

plt.figure(2)
# plt.plot(t, Y_E, label="Y_E")
# plt.plot(t, Y_RK, label="Y_RK")
plt.plot(t1, Y_solution, label='y(t)', linewidth = 3)
plt.xlabel("time(s)")
plt.ylabel("Y")
plt.title("Y vs time")
plt.legend()
plt.grid(True)

plt.figure(3)
# plt.plot(t, Z_E, label="Z_E")
# plt.plot(t, Z_RK, label="Z_RK")
plt.plot(t1, Z_solution, label='z(t)', linewidth = 3)
plt.xlabel("time(s)")
plt.ylabel("Z")
plt.title("Z vs time")
plt.legend()
plt.grid(True)

plt.show()
