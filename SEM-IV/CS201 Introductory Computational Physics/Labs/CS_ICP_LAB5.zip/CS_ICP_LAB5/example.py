"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-5 Question 2 initial code
    
"""

import numpy as np
import math as mt
import matplotlib.pyplot as plt

# My Values
a = 0
b = 170
n = 10000
h = (b-a)/n
t = np.arange(a, b, h)

g = 9.8
Wo = 0
Theta_o = 0.01
l = 10

# # Bhoomish Values
# a = 0
# b = 100
# n = 1000
# h = (b-a)/n
# t = np.arange(a, b, h)

# g = 10
# Wo = 0
# Theta_o = 0.1
# l = 15

Eo = g * l * 2 * (mt.sin(Theta_o*0.5)**2)

W_E = [Wo] * n
Theta_E = [Theta_o] * n
E_E = [Eo] * n

W_EC = [Wo] * n
Theta_EC = [Theta_o] * n
E_EC = [Eo] * n

W_RK = [Wo] * n
Theta_RK = [Theta_o] * n
E_RK = [Eo] * n

for i in range(1, n):

    # Euler Method
    W_E[i] = W_E[i-1] - (g * h / l) * mt.sin(Theta_E[i-1])
    Theta_E[i] =  h * W_E[i-1] + Theta_E[i-1]
    E_E[i] =  (0.5 * W_E[i] * W_E[i] * l * l) + (2 * g * l * mt.sin(Theta_E[i-1]*0.5) * mt.sin(Theta_E[i-1]*0.5))
    # KE + UE

    # Euler-Cromer Method
    W_EC[i] = W_EC[i-1] - (g * h / l) * mt.sin(Theta_EC[i-1])
    Theta_EC[i] =  h * W_EC[i] + Theta_EC[i-1]
    E_EC[i] =  (0.5 * W_EC[i] * W_EC[i] * l * l) + (2 * g * l * mt.sin(Theta_EC[i]*0.5) * mt.sin(Theta_EC[i]*0.5))
    # KE + PE

    # RK-4 Method
    # Ki for position W
    K1 = -(g * mt.sin(Theta_RK[i-1])) / l
    K2 = -(g * mt.sin(Theta_RK[i-1])) / l + h*K1/2
    K3 = -(g * mt.sin(Theta_RK[i-1])) / l + h*K2/2
    K4 = -(g * mt.sin(Theta_RK[i-1])) / l + h*K3
    W_RK[i] = W_RK[i-1] + h*(K1 + 2*K2 + 2*K3 + K4)/6

    # Ki for position Theta
    K1 = W_RK[i]
    K2 = W_RK[i] + h*K1/2
    K3 = W_RK[i] + h*K2/2
    K4 = W_RK[i] + h*K3
    Theta_RK[i] = Theta_RK[i-1] + h*(K1 + 2*K2 + 2*K3 + K4)/6
    E_RK[i] =  (0.5 * W_RK[i] * W_RK[i] * l * l) + (2 * g * l * mt.sin(Theta_RK[i]*0.5) * mt.sin(Theta_RK[i]*0.5))
    

plt.figure(1)
plt.plot(t, Theta_E, label="Euler Theta(t)")
plt.plot(t, Theta_EC, label="EC Theta(t)")
plt.plot(t, Theta_RK, label="RK-4 Theta(t)")
plt.xlabel("time(s)")
plt.ylabel("Theta")
plt.title("Theta vs time")
plt.legend()
plt.grid(True)

plt.figure(2)
plt.plot(t, W_E, label="Euler W(t)")
plt.plot(t, W_EC, label="EC W(t)")
plt.plot(t, W_RK, label="RK-4 W(t)")
plt.xlabel("time(s)")
plt.ylabel("W")
plt.title("W vs time")
plt.legend()
plt.grid(True)

plt.figure(3)
plt.plot(t, E_E, label="Euler E")
plt.plot(t, E_EC, label="EC E")
plt.plot(t, E_RK, label="RK-4 E")
plt.xlabel("time(s)")
plt.ylabel("Energy")
plt.title("Energy vs time")
plt.legend()
plt.grid(True)

plt.show()
