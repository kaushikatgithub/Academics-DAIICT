"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-7 Question 1(i)
    
"""

import numpy as np
import math as mt
import matplotlib.pyplot as plt

a = 0
b = 100
n = 10000
h = (b-a)/n
t = np.arange(a, b, h)

Fo = 1
Xo = 0
Vo = 1
Bita = 0.5
Wo = 2.5
W = 0.3

X = [Xo] * n
V = [Vo] * n


# Funtions for RK4 method
def Fv(T, X, V):
    return Fo * mt.cos(W*T) - (Wo ** 2) * X - 2 * Bita * V

def Fx(T, X, V):
    return V

# Loops for Euler and RK4
for i in range(1, n):
    
    # RK-4 Method
    # Ki for position V
    K1 = Fv(i*h, X[i-1], V[i-1])
    K2 = Fv(i*h + 0.5 * h, X[i-1] + 0.5 * h * K1, V[i-1] + 0.5 * h * K1)
    K3 = Fv(i*h + 0.5 * h, X[i-1] + 0.5 * h * K2, V[i-1] + 0.5 * h * K2)
    K4 = Fv(i*h + h, X[i-1] + h * K3, V[i-1] + h * K3)
    V[i] = V[i-1] + (h/6) * (K1 + 2 * K2 + 2 * K3 + K4) 

    # Ki for position X
    K1 = Fx(i*h, X[i-1], V[i-1])
    K2 = Fx(i*h + 0.5 * h, X[i-1] + 0.5 * h * K1, V[i-1] + 0.5 * h * K1)
    K3 = Fx(i*h + 0.5 * h, X[i-1] + 0.5 * h * K2, V[i-1] + 0.5 * h * K2)
    K4 = Fx(i*h + h, X[i-1] + h * K3, V[i-1] + h * K3)
    X[i] = X[i-1] + (h/6) * (K1 + 2 * K2 + 2 * K3 + K4) 


plt.figure(figsize=(8, 12), dpi = 110) # Figure dimension ratio
plt.suptitle("Forced-Damped Oscillator\n" + fr"Fo = {Fo}, Wo = {Wo}, $\beta$ = {Bita}, W = {W}", fontsize = 14)
plt.subplot(2, 1, 1)
plt.plot(t, X, label = "X(t)")
plt.xlabel("time(s)")
plt.ylabel("X(t)")
plt.title("X(t)")
plt.legend()
plt.grid(True)

plt.subplot(2, 1, 2)
plt.plot(t, V, label = "V(t)")
plt.xlabel("time(s)")
plt.ylabel("V(t)")
plt.title("V(t)")
plt.legend()
plt.grid(True)

plt.subplots_adjust(hspace=0.35, top=0.855)
# plt.savefig("ICP_LAB7_Q1(i).png")
plt.show()