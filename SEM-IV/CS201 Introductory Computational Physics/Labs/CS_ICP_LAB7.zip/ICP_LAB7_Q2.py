"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-7 Question 2
    
"""

import numpy as np
import math as mt
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp

a = 0
b = 80
n = 10000
h = (b-a)/n
t = np.arange(a, b, h)

X1o = 10
X2o = 10
V1o = 0
V2o = 0

m_values = [(1, 1), (1, 200), (1, 1)]
k_values = [(1, 1, 1), (1, 1, 1), (1, 0.1, 1)]

# Funtions for RK4 method
def Fv1(x1, x2, m, k):
    m1, m2 = m
    k1 = k[0]
    k2 = k[1]
    k3 = k[2]
    return (k2 * x2 - (k1 + k2) * x1) / m1

def Fv2(x1, x2, m, k):
    m1, m2 = m
    k1 = k[0]
    k2 = k[1]
    k3 = k[2]
    return (k2 * x1 - (k2 + k3) * x2) / m2

def plotGraphs(figNo, m, k):
    m1, m2 = m
    k1 = k[0]
    k2 = k[1]
    k3 = k[2]

    X1 = [X1o] * n
    X2 = [X2o] * n
    V1 = [V1o] * n
    V2 = [V2o] * n
    # Loops for Euler and RK4
    for i in range(1, n):

        # RK-4 Method
        # Ki for position V1
        K1 = Fv1(X1[i-1], X2[i-1], m, k)
        K2 = Fv1(X1[i-1] + 0.5 * h * K1, X2[i-1] + 0.5 * h * K1, m, k)
        K3 = Fv1(X1[i-1] + 0.5 * h * K2, X2[i-1] + 0.5 * h * K2, m, k)
        K4 = Fv1(X1[i-1] + h * K3, X2[i-1] + h * K3, m, k)
        V1[i] = V1[i-1] + (h/6) * (K1 + 2 * K2 + 2 * K3 + K4) 

        # Ki for position V2
        K1 = Fv2(X1[i-1], X2[i-1], m, k)
        K2 = Fv2(X1[i-1] + 0.5 * h * K1, X2[i-1] + 0.5 * h * K1, m, k)
        K3 = Fv2(X1[i-1] + 0.5 * h * K2, X2[i-1] + 0.5 * h * K2, m, k)
        K4 = Fv2(X1[i-1] + h * K3, X2[i-1] + h * K3, m, k)
        V2[i] = V2[i-1] + (h/6) * (K1 + 2 * K2 + 2 * K3 + K4)
        
        # RK-4 Method
        # Ki for position X1
        K1 = V1[i]
        K2 = V1[i] + h*K1/2
        K3 = V1[i] + h*K2/2
        K4 = V1[i] + h*K3
        X1[i] = X1[i-1] + (h/6) * (K1 + 2 * K2 +2 * K3 + K4) 

        # Ki for position X2
        K1 = V2[i]
        K2 = V2[i] + h*K1/2
        K3 = V2[i] + h*K2/2
        K4 = V2[i] + h*K3
        X2[i] = X2[i-1] + (h/6) * (K1 + 2 * K2 + 2 * K3 + K4) 


    plt.figure(figsize=(14, 15), dpi = 110) # Figure dimension ratio
    plt.suptitle(f"Values: (m1, m2) = ({m1}, {m2}), (k1, k2, k3) = ({k1}, {k2}, {k3})", fontweight='bold', fontsize = 14)
    plt.subplot(2, 2, 1)
    plt.plot(t, X1)
    plt.xlabel("time(s)")
    plt.ylabel("X1(t)")
    plt.title("X1(t)")
    plt.grid(True)

    plt.subplot(2, 2, 2)
    plt.plot(t, V1)
    plt.xlabel("time(s)")
    plt.ylabel("V1(t)")
    plt.title("V1(t)")
    plt.grid(True)

    plt.subplot(2, 2, 3)
    plt.plot(t, X2)
    plt.xlabel("time(s)")
    plt.ylabel("X2(t)")
    plt.title("X2(t)")
    plt.grid(True)

    plt.subplot(2, 2, 4)
    plt.plot(t, V2)
    plt.xlabel("time(s)")
    plt.ylabel("V2(t)")
    plt.title("V2(t)")
    plt.grid(True)

    plt.subplots_adjust(hspace=0.25)
    plt.subplots_adjust(wspace=0.2)


for i in range(3):
    plotGraphs(i, m_values[i], k_values[i])
    plt.savefig(f"ICP_LAB7_Q2({i+1}).png")


plt.show()