"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-7 Question 1(ii)
    
"""

import numpy as np
import math as mt
import matplotlib.pyplot as plt

a = 0
b = 50
n = 10000
h = (b-a)/n
t = np.arange(a, b, h)

Fo = 1
Xo = 0
Vo = 1
Beta = 0.5
Wo = 2.5

# Amplitude v/s W
W_list = np.arange(0.01, 5, 0.01)
Amplitude_list = Fo / np.sqrt((Wo**2 - W_list**2)**2 + (2 * Beta)**2 * W_list**2)
Amp_resonance, idx_resonance = 0, 0
for i in range(len(Amplitude_list)):
    if Amp_resonance <= Amplitude_list[i]:
        Amp_resonance = Amplitude_list[i]
        idx_resonance = i

W_resonance = W_list[idx_resonance]
print("Resonance frequency: ", W_resonance)

Wo_Values = [Wo, Wo, Wo]
W_Values = [W_resonance - 0.5, W_resonance, W_resonance + 0.5]
leg = ["Wo > W", "Wo = W", "Wo < W"]

def plotGraphs(fig_no, Wo, W, leg):
            
    # W = 0.99
    # Funtions for RK4 methods
    # global bita
    def Fv(T, X, V):
        return Fo * mt.cos(W*T) - (Wo ** 2) * X - 2 * Beta * V

    def Fx(T, X, V):
        return V
    
    X = [Xo] * n
    V = [Vo] * n

    for i in range(1, n):

        # RK-4 Method
        # Ki for position V
        K1 = Fv(i*h, X[i-1], V[i-1])
        K2 = Fv(i*h + 0.5 * h, X[i-1] + 0.5 * h * K1, V[i-1] + 0.5 * h * K1)
        K3 = Fv(i*h + 0.5 * h, X[i-1] + 0.5 * h * K2, V[i-1] + 0.5 * h * K2)
        K4 = Fv(i*h + h, X[i-1] + h * K3, V[i-1] + h * K3)
        V[i] = V[i-1] + (h/6) * (K1 + 2 * K2 + 2 * K3 + K4) 

        # Ki for position X
        K1 = Fx(i*h, X[i-1], V[i-1])
        K2 = Fx(i*h + 0.5 * h, X[i-1] + 0.5 * h * K1, V[i-1] + 0.5 * h * K1)
        K3 = Fx(i*h + 0.5 * h, X[i-1] + 0.5 * h * K2, V[i-1] + 0.5 * h * K2)
        K4 = Fx(i*h + h, X[i-1] + h * K3, V[i-1] + h * K3)
        X[i] = X[i-1] + (h/6) * (K1 + 2 * K2 + 2 * K3 + K4) 

    plt.figure(fig_no, figsize=(8, 12), dpi = 110) # Figure dimension ratio
    # plt.suptitle(f"Graphs using RK4 Method with W = {W}, Wo = {Wo}", fontweight='bold', fontsize = 14)
    plt.subplot(2, 1, 1)
    plt.plot(t, X, label = f"{leg}")
    plt.xlabel("time(s)")
    plt.ylabel("X(t)")
    plt.title("X(t)")
    plt.legend()
    plt.grid(True)

    plt.subplot(2, 1, 2)
    plt.plot(t, V, label = f"{leg}")
    plt.xlabel("time(s)")
    plt.ylabel("V(t)")
    plt.title("V(t)")
    plt.legend()
    plt.grid(True)

    plt.subplots_adjust(hspace=0.4)

for i in range(3):
    plotGraphs(0, Wo_Values[i], W_Values[i], leg[i])
# plt.savefig("ICP_LAB7_Q1(ii)_1.png")

plt.figure(2)
plt.plot(W_list, Amplitude_list)
# plt.savefig("ICP_LAB7_Q1(ii)_A.png")

plt.show()