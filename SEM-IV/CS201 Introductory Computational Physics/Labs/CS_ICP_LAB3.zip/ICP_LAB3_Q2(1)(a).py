"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-3 Question 1.2(b)
    
"""

# Import required libraries
import matplotlib.pyplot as plt
import numpy as np
import math as mt

m = 1
Bita = 10
P = 100
Vo_tup = [1, 10]  # m/s
h = 0.01
n = 100

def V(t, P, m, Bita, Vo):
    return np.sqrt((P - (P-Bita*(Vo**2))*np.exp((t*(-2*Bita))/m))/Bita)

t = np.linspace(0, n*h, n)
text = ["at low V", "at high V"]
for i in range(len(Vo_tup)):

    txt = text[i]
    Vo = Vo_tup[i]
    V_actual = V(t, P, m, Bita, Vo)
    V_aprx = [Vo]
    for i in range(1, n):
        V_aprx.append(V_aprx[-1]*(1-(Bita*h)/m) + (P*h)/(m*V_aprx[-1]))
 
    plt.figure(figsize=(7, 6), dpi = 100)  # Figure dimension ratio
    plt.plot(t, V_actual, label = "Actual V(t)")
    plt.plot(t, V_aprx, label = "Aprx V(t)")
    plt.title(f"Velocity of Bicycle {txt}", fontsize=12)
    plt.xlabel('time(s)', fontsize=12)
    plt.ylabel('V(t) (m/s)', fontsize=12)
    plt.grid(True)
    plt.legend(fontsize=12)

plt.show()
