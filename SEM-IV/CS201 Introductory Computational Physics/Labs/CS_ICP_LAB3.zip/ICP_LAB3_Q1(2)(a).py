"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-3 Question 1.2(a)
    
"""

# Import required libraries
import matplotlib.pyplot as plt
import numpy as np
import math as mt

m = 1
Bita = -1
g = -9.8 
Vo = 10 # m/s
Theta = np.pi/4

h = 0.01
n = 125
Xo = 0.00
Yo = 0.00
Vo_x = Vo * np.cos(Theta)
Vo_y = Vo * np.sin(Theta)


t = [0.00]
X = [Xo]
Y = [Yo]
V_x = [Vo_x]
V_y = [Vo_y]

Tf = 0

for i in range(1, n):
    V_x.append(V_x[-1] + (V_x[-1]*(h*Bita)/m))
    V_y.append(V_y[-1] + (V_y[-1]*(h*Bita)/m) + (g*h)/m)
    X.append(X[-1] + V_x[i-1]*h)
    Y.append(Y[-1] + V_y[i-1]*h)
    t.append(i*h)
    if Y[i] >= 0.00:
        Tf = t[i]

print("Total Flying Time Numerically: " ,Tf)

plt.figure(figsize=(7, 6), dpi = 100) # Figure dimension ratio
plt.plot(t, V_x, label = "Vx(t)")
plt.title("X component of Velocity", fontsize=12)
plt.xlabel('time(s)', fontsize=12)
plt.ylabel('Vx(t) (m/s)', fontsize=12)
plt.grid(True)
# plt.xlim([0, 1])
# plt.ylim([2, 8])
plt.legend(fontsize=12)

plt.figure(figsize=(7, 6), dpi = 100) # Figure dimension ratio
plt.plot(t, V_y, label = "Vy(t)")
plt.title("Y component of Velocity", fontsize=12)
plt.xlabel('time(s)', fontsize = 12)
plt.ylabel('Vy(t) (m/s)', fontsize = 12)
plt.grid(True)
# plt.xlim([0, 0.6])
# plt.ylim([0, 8])
plt.legend(fontsize = 12)

plt.figure(figsize=(7, 6), dpi = 100) # Figure dimension ratio
plt.plot(X, Y, label = "Trajectory")
plt.title("Trajectory", fontsize=12)
plt.xlabel('X(t)', fontsize=12)
plt.ylabel('Y(t)', fontsize=12)
plt.grid(True)
plt.xlim([0, 5])
plt.ylim([0, 2])
plt.legend(fontsize=12)

plt.show()
