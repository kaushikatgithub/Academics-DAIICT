"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-3 Question 1.1
    
"""

import numpy as np
import math as mt
import matplotlib.pyplot as plt

h = 0.01
n = 1000

Vo = 10.00
g = 9.8
Theta = np.pi/4
Voy = Vo * np.sin(Theta)
Vox = Vo * np.cos(Theta)
Xo = 0.00
Yo = 0.00


Vy = [Voy]
Vx = [Vox]
Y = [Xo]
X = [Yo ]
t = [0.00]

Tf = 0

for i in range(1,n):
  Vy.append(Vy[-1] - g*h)
  Vx.append(Vx[-1])
  t.append(i * h)
  if Vy[i] >=0.00:
    Tf = 2*t[i]

for i in range(1,n):
  Y.append(Vy[i-1]*h + Y[-1])
  X.append(Vx[i-1]*h + X[-1])


print("Total Flying Time Numerically: ", Tf)
print("Total Flying Time Analytically: ", 2 * Voy / g)

plt.figure(1)
plt.plot(t, Vy, label="Vy(t)")
plt.plot(t, Vx, label="Vx(t)")
plt.title("Velocity", fontsize=12)
plt.xlabel('X(t)', fontsize=12)
plt.ylabel('Y(t)', fontsize=12)
plt.grid(True)
plt.ylim([0,10])
plt.xlim([0,0.75])
plt.legend()

plt.figure(2)
plt.plot(X,Y)
plt.title("Trajectory", fontsize=12)
plt.xlabel('X(t)', fontsize=12)
plt.ylabel('Y(t)', fontsize=12)
plt.grid(True)
plt.ylim([0, 3])
plt.xlim([0, 10.5])
plt.grid(True)

plt.show()