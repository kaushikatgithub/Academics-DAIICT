"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-3 Question 1.2(b)
    
"""

# Import required libraries
import matplotlib.pyplot as plt
import numpy as np
import math as mt

m = 1
Area_tup = [0.5, 1, 2, 3]
rho_tup = [0.5, 1, 2, 3]
P = 1
Vo = 1  # m/s
h = 0.01
n = 100

plt.figure(figsize=(7, 6), dpi = 100) # Figure dimension ratio

for k in range(4):
    rho = rho_tup[k]
    A = Area_tup[k]
    t = [0.00]
    V_aprx = [Vo]

    for i in range(1, n):
        V_aprx.append(V_aprx[-1]-((0.5*rho*A*h)/m)*(V_aprx[-1]*V_aprx[-1]) + (P*h)/(m*V_aprx[-1]))
        t.append(i*h)
    plt.plot(t, V_aprx, label = f'A=${A}, rho=${rho}')

plt.title("Velocity of Bicycle", fontsize=12)
plt.xlabel('time(s)', fontsize=12)
plt.ylabel('V(t) (m/s)', fontsize=12)
plt.grid(True)
# plt.xlim([0, 1])
# plt.ylim([-1, 8])
plt.legend(fontsize=8)

plt.show()
