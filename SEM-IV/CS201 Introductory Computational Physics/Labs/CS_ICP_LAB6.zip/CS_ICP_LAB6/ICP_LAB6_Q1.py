"""
    Vraj Gandhi        - 202201425 
    Kaushik Prajapati  - 202201472
    CT Lab-5 Question 1
    
"""

import numpy as np
import math as mt
import matplotlib.pyplot as plt

a = 0
b = 10
n = 10000
h = (b-a)/n
t = np.arange(a, b, h)

Bita_Wo_Values = [(2.1, 2, "Overdamped (B > Wo)"), (8, 2, "Overdamped (B >> Wo)"), (1.9, 2, "Underdamped (B < Wo)"), (0.5, 2, "Underdamped (B << Wo)"), (2, 2, "Crtitical Damping (B = Wo)")]

def plot_Graphs(Bita, Wo, leg):

    Xo = 0
    Vo = 1
    Eo = 0.5 * (Vo*Vo + (Wo**2) * (Xo**2))

    X = [Xo] * n
    X[1] = (X[0] * (2 + 2 * Bita * h - (h**2) * (Wo**2)) + h*Vo + Xo) / (2 * Bita * h + 1)

    V = [Vo] * n
    V[1] = (X[1] - X[0])/h

    E = [Eo] * n
    E[1] = 0.5 * (V[1] * V[1] + (Wo**2) * (X[1]**2))

    for i in range(2, n):
        X[i] = (X[i-1] * (2 + 2 * Bita * h - (h**2) * (Wo**2)) - X[i-2]) / (2 * Bita * h + 1)
        V[i] = (X[i] - X[i-1])/h
        E[i] = 0.5 * (V[i] * V[i] + (Wo**2) * (X[i]**2))

    # plt.figure(1)
    plt.subplot(3, 1, 1)
    plt.plot(t, X, label = f"{leg}")
    plt.xlabel("time(s)")
    plt.ylabel("X(t)")
    plt.title("X(t) vs time")
    plt.legend(fontsize = 7)
    plt.grid(True)

    # plt.figure(2)
    plt.subplot(3, 1, 2)
    plt.plot(t, V, label = f"{leg}")
    plt.xlabel("time(s)")
    plt.ylabel("V(t)")
    plt.title("V(t) vs time")
    plt.legend(fontsize = 7)
    plt.grid(True)

    # plt.figure(3)
    plt.subplot(3, 1, 3)
    plt.plot(t, E, label = f"{leg}")
    plt.xlabel("time(s)")
    plt.ylabel("E(t)")
    plt.title("E(t) vs time")
    plt.legend(fontsize = 7)
    plt.grid(True)

plt.figure(figsize=(7, 12), dpi = 110)
plt.suptitle("Oscillatory Motion", fontweight='bold', fontsize = 14)

for i in range(len(Bita_Wo_Values)):
    plot_Graphs(Bita_Wo_Values[i][0], Bita_Wo_Values[i][1], Bita_Wo_Values[i][2])

plt.subplots_adjust(hspace=0.5)
plt.subplots_adjust(wspace=0.1) 
plt.savefig("ICP_LAB6_Q1.png")
plt.show()



